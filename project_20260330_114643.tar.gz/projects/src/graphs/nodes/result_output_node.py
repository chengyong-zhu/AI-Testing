"""
最终结果输出节点 - 汇总所有结果并生成最终报告
"""
import os
from typing import Dict, Any, List
from datetime import datetime
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from graphs.state import ResultOutputInput, ResultOutputOutput


def result_output_node(
    state: ResultOutputInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> ResultOutputOutput:
    """
    title: 最终结果输出
    desc: 汇总PRD评估和测试用例评估结果，生成最终报告（支持完善后的测试用例）
    """
    ctx = runtime.context
    
    # 生成最终报告
    report_lines = []
    
    # 报告头部
    report_lines.append("# PRD测试准入与测试用例质量评估报告")
    report_lines.append(f"\n**评估时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
    
    # PRD评估结果
    report_lines.append("## 一、PRD测试准入评估结果\n")
    
    status_emoji = "✅" if state.prd_evaluation_passed else "❌"
    status_text = "通过" if state.prd_evaluation_passed else "未通过"
    
    report_lines.append(f"### 评估结论\n")
    report_lines.append(f"- **评估分数**: {state.prd_evaluation_score:.1f}分")
    report_lines.append(f"- **准入状态**: {status_emoji} {status_text} (阈值: ≥80分)\n")
    
    # PRD评估报告下载链接
    if state.prd_evaluation_report_url:
        report_lines.append(f"### 📄 评估报告下载\n")
        report_lines.append(f"[下载PRD评估报告PDF]({state.prd_evaluation_report_url})\n")
    
    if state.prd_evaluation_passed:
        report_lines.append(f"> PRD评估分数达到准入阈值，已进入测试用例生成环节。\n")
    else:
        report_lines.append(f"> ⚠️ PRD评估分数未达到准入阈值，无法进入测试设计环节。请参考评估报告进行整改。\n")
    
    report_lines.append("### PRD详细评估报告\n")
    report_lines.append(state.prd_evaluation_report)
    
    # 如果PRD通过，展示测试用例结果
    if state.prd_evaluation_passed:
        report_lines.append("\n---\n")
        report_lines.append("## 二、测试用例生成结果\n")
        
        if state.test_case_excel_url:
            report_lines.append(f"### 📊 测试用例文件下载\n")
            report_lines.append(f"[下载测试用例Excel]({state.test_case_excel_url})\n")
        
        if state.test_cases:
            report_lines.append(f"### 用例统计\n")
            p1_count = sum(1 for tc in state.test_cases if tc.get("priority") == "P1" or tc.get("优先级") == "P1")
            p2_count = sum(1 for tc in state.test_cases if tc.get("priority") == "P2" or tc.get("优先级") == "P2")
            p3_count = sum(1 for tc in state.test_cases if tc.get("priority") == "P3" or tc.get("优先级") == "P3")
            p4_count = sum(1 for tc in state.test_cases if tc.get("priority") == "P4" or tc.get("优先级") == "P4")
            
            report_lines.append(f"- 总用例数: {len(state.test_cases)}")
            report_lines.append(f"- P1(核心): {p1_count}个")
            report_lines.append(f"- P2(重要): {p2_count}个")
            report_lines.append(f"- P3(一般): {p3_count}个")
            report_lines.append(f"- P4(次要): {p4_count}个\n")
        
        # 测试用例质量评估结果
        report_lines.append("## 三、测试用例质量评估结果\n")
        
        quality_status = "优秀" if state.test_case_evaluation_score >= 90 else "良好" if state.test_case_evaluation_score >= 80 else "合格" if state.test_case_evaluation_score >= 70 else "待改进"
        quality_emoji = "✅" if state.test_case_evaluation_score >= 90 else "⚠️"
        
        report_lines.append(f"### 评估结论\n")
        report_lines.append(f"- **评估分数**: {state.test_case_evaluation_score:.1f}分")
        report_lines.append(f"- **质量等级**: {quality_emoji} {quality_status} (阈值: ≥90分为优秀)\n")
        
        # 测试用例评估报告下载链接
        if state.test_case_evaluation_report_url:
            report_lines.append(f"### 📄 评估报告下载\n")
            report_lines.append(f"[下载测试用例质量评估报告PDF]({state.test_case_evaluation_report_url})\n")
        
        # 判断是否进行了完善
        if state.refinement_count > 0 and state.refined_test_case_excel_url:
            # 显示完善后的结果
            report_lines.append(f"> ⚠️ 原始测试用例评估分数未达到优秀标准（{state.test_case_evaluation_score:.1f}分），已自动进行1轮完善。\n")
            
            report_lines.append("\n### 📊 完善后测试用例文件下载\n")
            report_lines.append(f"[下载完善后测试用例Excel]({state.refined_test_case_excel_url})\n")
            
            if state.refined_test_cases:
                report_lines.append(f"\n### 完善后用例统计\n")
                rp1_count = sum(1 for tc in state.refined_test_cases if tc.get("priority") == "P1" or tc.get("优先级") == "P1")
                rp2_count = sum(1 for tc in state.refined_test_cases if tc.get("priority") == "P2" or tc.get("优先级") == "P2")
                rp3_count = sum(1 for tc in state.refined_test_cases if tc.get("priority") == "P3" or tc.get("优先级") == "P3")
                rp4_count = sum(1 for tc in state.refined_test_cases if tc.get("priority") == "P4" or tc.get("优先级") == "P4")
                
                report_lines.append(f"- 总用例数: {len(state.refined_test_cases)}")
                report_lines.append(f"- P1(核心): {rp1_count}个")
                report_lines.append(f"- P2(重要): {rp2_count}个")
                report_lines.append(f"- P3(一般): {rp3_count}个")
                report_lines.append(f"- P4(次要): {rp4_count}个\n")
            
            # 完善后的评估结果
            report_lines.append("\n### 完善后质量评估结果\n")
            
            refined_quality_status = "优秀" if state.refined_test_case_evaluation_score >= 90 else "良好" if state.refined_test_case_evaluation_score >= 80 else "合格" if state.refined_test_case_evaluation_score >= 70 else "待改进"
            refined_quality_emoji = "✅" if state.refined_test_case_evaluation_score >= 90 else "⚠️"
            
            report_lines.append(f"- **完善后评估分数**: {state.refined_test_case_evaluation_score:.1f}分")
            report_lines.append(f"- **质量等级**: {refined_quality_emoji} {refined_quality_status}\n")
            
            if state.refined_test_case_evaluation_report_url:
                report_lines.append(f"\n### 📄 完善后评估报告下载\n")
                report_lines.append(f"[下载完善后测试用例质量评估报告PDF]({state.refined_test_case_evaluation_report_url})\n")
            
            if state.refined_test_case_evaluation_score >= 90:
                report_lines.append(f"> ✅ 完善后测试用例质量达到优秀标准，可直接用于测试工作。\n")
            else:
                report_lines.append(f"> ⚠️ 完善后测试用例质量仍未达到优秀标准。建议参考完善后评估报告进行人工优化。\n")
        else:
            if state.test_case_evaluation_score >= 90:
                report_lines.append(f"> 测试用例质量评估达到优秀标准，可直接用于测试工作。\n")
            else:
                report_lines.append(f"> ⚠️ 测试用例质量评估未达到优秀标准。请参考以下修改意见进行优化。\n")
                if state.test_case_modification_suggestions:
                    report_lines.append("\n### 修改建议\n")
                    report_lines.append(state.test_case_modification_suggestions)
        
        report_lines.append("\n### 测试用例详细评估报告\n")
        report_lines.append(state.test_case_evaluation_report)
    
    # 报告尾部
    report_lines.append("\n---\n")
    report_lines.append("*报告生成时间: " + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + "*")
    
    final_report = "\n".join(report_lines)
    
    return ResultOutputOutput(final_report=final_report)
