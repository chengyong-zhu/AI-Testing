"""
测试用例完善后质量评估节点 - 对完善后的测试用例进行质量评估
"""
import os
import json
import re
import tempfile
import logging
from datetime import datetime
from typing import Dict, Any, List
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from coze_coding_dev_sdk import LLMClient
from coze_coding_dev_sdk.s3 import S3SyncStorage
from langchain_core.messages import SystemMessage, HumanMessage
from jinja2 import Template
from graphs.state import TestCaseQualityRefinementInput, TestCaseQualityRefinementOutput

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def _extract_json_from_response(content: str) -> Dict[str, Any]:
    """从LLM响应中提取JSON"""
    json_pattern = r'```json\s*([\s\S]*?)\s*```'
    matches = re.findall(json_pattern, content)
    
    if matches:
        try:
            return json.loads(matches[0])
        except json.JSONDecodeError:
            pass
    
    try:
        return json.loads(content)
    except json.JSONDecodeError:
        pass
    
    json_obj_pattern = r'\{[\s\S]*\}'
    match = re.search(json_obj_pattern, content)
    if match:
        try:
            return json.loads(match.group())
        except json.JSONDecodeError:
            pass
    
    return {}


def _calculate_total_score(result: Dict[str, Any]) -> float:
    """计算总分"""
    dimensions = result.get("各维度详细评估", {})
    total_score = 0.0
    
    for dim_name, dim_info in dimensions.items():
        if isinstance(dim_info, dict):
            score = dim_info.get("得分", 0)
            if isinstance(score, (int, float, str)):
                try:
                    total_score += float(score)
                except (ValueError, TypeError):
                    pass
    
    return total_score


def _generate_html_report(result: Dict[str, Any]) -> str:
    """生成测试用例质量评估报告HTML（使用与原始评估相同的模板）"""
    current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    
    # 提取关键信息
    overall = result.get("总体评价", {})
    dimensions = result.get("各维度详细评估", {})
    problems = result.get("问题清单", {})
    optimization = result.get("优化优先级建议", {})
    examples = result.get("优化示例", [])
    summary = result.get("总结", {})
    appendix = result.get("附录", {})
    
    html = """<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>测试用例质量评估报告</title>
    <style>
        body { font-family: "Microsoft YaHei", Arial, sans-serif; margin: 20px; background-color: #f5f5f5; }
        .page { max-width: 1000px; margin: 0 auto; background-color: white; padding: 30px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        .header { text-align: center; margin-bottom: 30px; border-bottom: 2px solid #3A7BB3; padding-bottom: 15px; }
        .header h1 { color: #3A7BB3; margin: 0; }
        table { width: 100%; border-collapse: collapse; margin: 15px 0; }
        th { background-color: #3A7BB3; color: white; padding: 10px; text-align: left; }
        td { padding: 8px; border-bottom: 1px solid #ddd; }
        .level1 { font-size: 16px; font-weight: bold; margin: 20px 0 10px 0; color: #3A7BB3; }
        .level2 { font-size: 14px; font-weight: bold; margin: 15px 0 10px 0; }
        .level3 { font-size: 13px; font-weight: bold; margin: 10px 0 8px 0; }
        .highlight { color: #4CAF50; }
        .pass { color: #4CAF50; }
        .warning { color: #FF9800; }
        .fail { color: #F44336; }
        .na { color: #9E9E9E; }
        .minor { color: #666; font-size: 12px; }
        .footer { margin-top: 30px; padding-top: 15px; border-top: 1px solid #ddd; font-size: 12px; color: #666; }
        .example-box { background-color: #f9f9f9; padding: 15px; margin: 10px 0; border-left: 3px solid #3A7BB3; }
        .before { color: #F44336; }
        .after { color: #4CAF50; }
    </style>
</head>
<body>
<div class="page">
    <div class="header">
        <h1>测试用例质量评估报告</h1>
    </div>
"""
    
    # 一、总体评价
    html += """
    <div class="level1">一、总体评价</div>
    <table>
        <tr><th>综合得分</th><th>评级</th><th>评估日期</th></tr>
"""
    html += f"        <tr><td>{overall.get('综合得分', '-')}</td><td>{overall.get('评级', '-')}</td><td>{overall.get('评估日期', '-')}</td></tr>\n"
    html += "    </table>\n"
    html += f"    <p><strong>总体评价：</strong>{overall.get('总体评价描述', '-')}</p>\n"
    
    # 二、各维度详细评估
    html += """
    <div class="level1">二、各维度详细评估</div>
    <table>
        <tr><th>维度</th><th>得分</th><th>满分</th><th>得分率</th></tr>
"""
    dimension_names = ["用例完整性", "用例有效性", "用例规范性", "用例针对性", "用例可执行性", "用例可维护性", "用例数据适配性"]
    for dim_name in dimension_names:
        dim_info = dimensions.get(dim_name, {})
        score = dim_info.get("得分", 0)
        full_score = dim_info.get("满分", 0)
        score_rate = f"{(score/full_score*100):.1f}%" if full_score > 0 else "0%"
        html += f"        <tr><td>{dim_name}</td><td>{score}</td><td>{full_score}</td><td>{score_rate}</td></tr>\n"
    
    html += "    </table>\n"
    
    # 各维度详细说明
    for dim_name in dimension_names:
        dim_info = dimensions.get(dim_name, {})
        if dim_info:
            html += f"""
    <div class="level2">{dim_name}</div>
    <p><strong>评估说明：</strong>{dim_info.get('评估说明', '-')}</p>
"""
            # 优点
            advantages = dim_info.get("优点", [])
            if advantages:
                html += '    <div class="level3">优点</div>\n    <ul>\n'
                for adv in advantages:
                    html += f"        <li class=\"pass\">{adv}</li>\n"
                html += "    </ul>\n"
            
            # 不足
            disadvantages = dim_info.get("不足", [])
            if disadvantages:
                html += '    <div class="level3">不足</div>\n    <ul>\n'
                for dis in disadvantages:
                    html += f"        <li class=\"warning\">{dis}</li>\n"
                html += "    </ul>\n"
            
            # 改进建议
            suggestions = dim_info.get("改进建议", [])
            if suggestions:
                html += '    <div class="level3">改进建议</div>\n    <ul>\n'
                for sug in suggestions:
                    html += f"        <li>{sug}</li>\n"
                html += "    </ul>\n"
    
    # 三、问题清单
    html += """
    <div class="level1">三、问题清单</div>
"""
    
    for level in ["严重问题", "中等问题", "轻微问题"]:
        problem_list = problems.get(level, [])
        if problem_list:
            html += f"""
    <div class="level2">{level}</div>
    <table>
        <tr><th style="width:10%">序号</th><th style="width:60%">问题</th><th style="width:30%">影响维度</th></tr>
"""
            for idx, p in enumerate(problem_list, 1):
                html += f"        <tr><td class=\"minor\">{idx}</td><td>{p.get('问题', '-')}</td><td>{p.get('影响维度', '-')}</td></tr>\n"
            html += "    </table>\n"
    
    # 四、优化优先级建议
    html += """
    <div class="level1">四、优化优先级建议</div>
"""
    
    phase_idx = 0
    phase_order = ["第一阶段", "第二阶段", "第三阶段", "第四阶段"]
    for phase_name in phase_order:
        phase_info = optimization.get(phase_name, {})
        if phase_info:
            phase_idx += 1
            html += f"""
    <div class="level2">{phase_idx}.{phase_name}（{phase_info.get('执行周期', '-')}）</div>
    <p><strong>阶段目标：</strong>{phase_info.get('阶段目标', '-')}</p>
"""
            measures = phase_info.get("优化措施", [])
            if measures:
                html += "    <ol>\n"
                for m in measures:
                    html += f"        <li>{m}</li>\n"
                html += "    </ol>\n"
    
    # 五、优化示例
    if examples:
        html += """
    <div class="level1">五、优化示例</div>
"""
        for idx, ex in enumerate(examples, 1):
            html += f"""
    <div class="level2">{idx}.{ex.get('示例标题', f'示例{idx}')}</div>
    <div class="example-box">
        <p class="before"><strong>优化前：</strong></p>
        <ul>
"""
            for before in ex.get("优化前", []):
                html += f"            <li>{before}</li>\n"
            html += """        </ul>
        <p class="after"><strong>优化后：</strong></p>
        <ul>
"""
            for after in ex.get("优化后", []):
                html += f"            <li>{after}</li>\n"
            html += "        </ul>\n    </div>\n"
    
    # 六、总结
    html += """
    <div class="level1">六、总结</div>
"""
    
    summary_idx = 0
    # 核心优势
    advantages = summary.get("核心优势", [])
    if advantages:
        summary_idx += 1
        html += f"""
    <div class="level2">{summary_idx}.核心优势</div>
    <ol>
"""
        for adv in advantages:
            html += f"        <li>{adv}</li>\n"
        html += "    </ol>\n"
    
    # 核心短板
    shortcomings = summary.get("核心短板", [])
    if shortcomings:
        summary_idx += 1
        html += f"""
    <div class="level2">{summary_idx}.核心短板</div>
    <ol>
"""
        for short in shortcomings:
            html += f"        <li>{short}</li>\n"
        html += "    </ol>\n"
    
    # 优化价值
    optimization_value = summary.get('优化价值', '暂无优化价值说明')
    if optimization_value:
        summary_idx += 1
        html += f"""
    <div class="level2">{summary_idx}.优化价值</div>
    <p>{optimization_value}</p>
"""
    
    # 附录
    stats = appendix.get("用例统计汇总", [])
    if stats:
        html += """
    <div class="level1">附录</div>
    <div class="level2">A.用例统计汇总</div>
    <table>
        <tr><th>统计项</th><th>数值</th><th>占比</th></tr>
"""
        for stat in stats:
            html += f"        <tr><td>{stat.get('统计项', '-')}</td><td>{stat.get('数值', 0)}</td><td>{stat.get('占比', '0%')}</td></tr>\n"
        html += "    </table>\n"
    
    # 报告尾部信息
    html += f"""
    <div class="footer">
        <p>报告生成时间：{current_time}</p>
        <p>评估工具：测试用例质量评估系统 V1.0</p>
        <p>评估有效期：自评估之日起3个月内有效，如测试用例有重大修订需重新评估</p>
    </div>
</div>
</body>
</html>
"""
    
    return html


def _generate_pdf_report(result: Dict[str, Any]) -> str:
    """生成PDF报告并上传，返回URL"""
    
    # 生成HTML
    html_content = _generate_html_report(result)
    
    # 生成PDF
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"TestCase_Quality_Report_{timestamp}.pdf"
    html_path = os.path.join(tempfile.gettempdir(), f"quality_report_{timestamp}.html")
    pdf_path = os.path.join(tempfile.gettempdir(), filename)
    
    # 保存HTML
    with open(html_path, 'w', encoding='utf-8') as f:
        f.write(html_content)
    
    # 强制使用weasyprint生成PDF，不允许降级为HTML
    from weasyprint import HTML
    HTML(filename=html_path).write_pdf(pdf_path)
    
    # 上传到对象存储
    storage = S3SyncStorage(
        endpoint_url=os.getenv("COZE_BUCKET_ENDPOINT_URL"),
        access_key="",
        secret_key="",
        bucket_name=os.getenv("COZE_BUCKET_NAME"),
        region="cn-beijing",
    )
    
    with open(pdf_path, 'rb') as f:
        file_content = f.read()
    
    object_key = storage.upload_file(
        file_content=file_content,
        file_name=filename,
        content_type="application/pdf",
    )
    
    # 生成预签名URL
    signed_url = storage.generate_presigned_url(key=object_key, expire_time=3600)
    return signed_url


def test_case_quality_refinement_node(
    state: TestCaseQualityRefinementInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> TestCaseQualityRefinementOutput:
    """
    title: 完善后测试用例质量评估
    desc: 对完善后的测试用例进行七维度质量评估，生成PDF报告
    integrations: test-case-evaluator, storage
    """
    ctx = runtime.context
    
    # 读取配置文件（复用原始评估的配置）
    cfg_path = os.path.join(os.getenv("COZE_WORKSPACE_PATH", ""), "config", "test_case_quality_llm_cfg.json")
    try:
        with open(cfg_path, 'r', encoding='utf-8') as f:
            cfg = json.load(f)
        llm_config = cfg.get("config", {})
        sp = cfg.get("sp", "")
        up = cfg.get("up", "")
    except Exception as e:
        logger.error(f"读取配置文件失败: {e}")
        llm_config = {
            "model": "doubao-seed-2-0-pro-260215",
            "temperature": 0.3,
            "max_completion_tokens": 32768
        }
        sp = ""
        up = ""
    
    # 将测试用例转为JSON字符串
    test_cases_json = json.dumps(state.refined_test_cases, ensure_ascii=False, indent=2)
    
    # 使用jinja2渲染用户提示词
    up_tpl = Template(up)
    user_prompt = up_tpl.render({
        "prd_content": state.prd_content,
        "test_cases_json": test_cases_json
    })
    
    # 调用大模型进行评估
    client = LLMClient(ctx=ctx)
    
    messages = [
        SystemMessage(content=sp),
        HumanMessage(content=user_prompt)
    ]
    
    response = client.invoke(
        messages=messages,
        model=llm_config.get("model", "doubao-seed-2-0-pro-260215"),
        temperature=llm_config.get("temperature", 0.3),
        max_completion_tokens=llm_config.get("max_completion_tokens", 32768)
    )
    
    # 处理响应内容
    response_content = response.content
    if isinstance(response_content, list):
        text_parts = []
        for item in response_content:
            if isinstance(item, dict) and item.get("type") == "text":
                text_parts.append(item.get("text", ""))
            elif isinstance(item, str):
                text_parts.append(item)
        response_content = "\n".join(text_parts)
    
    logger.info(f"LLM响应长度: {len(str(response_content))}")
    
    # 提取JSON结果
    result = _extract_json_from_response(str(response_content))
    
    if not result:
        logger.error("无法解析LLM响应，使用默认结果")
        result = {
            "业务模块": "测试用例",
            "总体评价": {
                "综合得分": "70/100",
                "评级": "合格",
                "评估日期": datetime.now().strftime('%Y-%m-%d'),
                "总体评价描述": "LLM响应解析失败，使用默认评分"
            },
            "各维度详细评估": {
                "用例完整性": {"得分": 20, "满分": 28, "评估说明": "默认评分", "优点": [], "不足": ["无法解析"], "改进建议": []},
                "用例有效性": {"得分": 15, "满分": 23, "评估说明": "默认评分", "优点": [], "不足": [], "改进建议": []},
                "用例规范性": {"得分": 15, "满分": 18, "评估说明": "默认评分", "优点": [], "不足": [], "改进建议": []},
                "用例针对性": {"得分": 10, "满分": 14, "评估说明": "默认评分", "优点": [], "不足": [], "改进建议": []},
                "用例可执行性": {"得分": 5, "满分": 7, "评估说明": "默认评分", "优点": [], "不足": [], "改进建议": []},
                "用例可维护性": {"得分": 3, "满分": 5, "评估说明": "默认评分", "优点": [], "不足": [], "改进建议": []},
                "用例数据适配性": {"得分": 2, "满分": 5, "评估说明": "默认评分", "优点": [], "不足": [], "改进建议": []}
            },
            "问题清单": {"严重问题": [], "中等问题": [], "轻微问题": []},
            "优化优先级建议": {},
            "优化示例": [],
            "总结": {"核心优势": [], "核心短板": [], "优化价值": ""},
            "附录": {"用例统计汇总": []}
        }
    
    # 计算分数
    total_score = _calculate_total_score(result)
    logger.info(f"完善后测试用例评估分数: {total_score}")
    
    # 生成PDF报告
    pdf_url = _generate_pdf_report(result)
    
    return TestCaseQualityRefinementOutput(
        refined_test_case_evaluation_score=total_score,
        refined_test_case_evaluation_report_url=pdf_url
    )
