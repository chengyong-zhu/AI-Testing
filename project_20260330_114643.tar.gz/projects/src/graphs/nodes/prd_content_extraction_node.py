"""
PRD内容提取节点 - 从PRD文档中提取文本内容
"""
import os
from typing import Dict, Any
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from utils.file.file import File, FileOps
from graphs.state import PrdContentExtractionInput, PrdContentExtractionOutput


def prd_content_extraction_node(
    state: PrdContentExtractionInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> PrdContentExtractionOutput:
    """
    title: PRD内容提取
    desc: 从上传的PRD文档中提取文本内容，支持PDF、Word、Excel等格式
    """
    ctx = runtime.context
    
    prd_file = state.prd_document
    
    # 检查文件类型并提取内容
    try:
        content = FileOps.extract_text(prd_file)
        
        if content.startswith("[FileOps Error]") or content.startswith("[解析失败]"):
            raise Exception(f"文档解析失败: {content}")
        
        # 清理内容
        content = content.strip()
        
        if not content:
            raise Exception("文档内容为空")
        
        return PrdContentExtractionOutput(prd_content=content)
        
    except Exception as e:
        raise Exception(f"PRD文档内容提取失败: {str(e)}")
