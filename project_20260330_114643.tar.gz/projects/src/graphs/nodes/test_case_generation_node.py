"""
测试用例生成节点 - 使用test-case-generator技能生成测试用例
合并Excel生成功能
"""
import os
import json
import re
import tempfile
import logging
from datetime import datetime
from typing import Dict, Any, List, Tuple
from jinja2 import Template
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from coze_coding_dev_sdk import LLMClient
from coze_coding_dev_sdk.s3 import S3SyncStorage
from langchain_core.messages import SystemMessage, HumanMessage
from graphs.state import TestCaseGenerationInput, TestCaseGenerationOutput

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def _count_steps(text: str) -> int:
    """统计步骤/预期结果的数量"""
    if not text:
        return 0
    # 匹配 #1. #2. 等格式
    pattern = r'#(\d+)\.'
    matches = re.findall(pattern, text)
    return len(matches)


def _validate_and_fix_test_case(case: Dict[str, Any]) -> Dict[str, Any]:
    """校验并修复测试用例的步骤与预期结果对应关系"""
    steps = case.get("steps", "")
    expected_results = case.get("expectedResults", "")
    
    # 也支持中文键名
    if not steps:
        steps = case.get("步骤描述", "")
    if not expected_results:
        expected_results = case.get("预期结果", "")
    
    step_count = _count_steps(steps)
    result_count = _count_steps(expected_results)
    
    if step_count == result_count:
        return case
    
    # 数量不匹配，需要修复
    logger.warning(f"测试用例步骤与预期结果数量不匹配: 步骤{step_count}条, 预期结果{result_count}条, 用例: {case.get('caseName', case.get('用例名称', '未知'))}")
    
    # 解析步骤和预期结果
    steps_list = _parse_numbered_items(steps)
    results_list = _parse_numbered_items(expected_results)
    
    # 修复策略：以步骤数量为准，补充或合并预期结果
    if step_count > result_count:
        # 步骤多，预期结果少：补充预期结果
        while len(results_list) < len(steps_list):
            # 复制最后一条预期结果或创建通用的
            if results_list:
                results_list.append(f"步骤{len(results_list) + 1}执行成功")
            else:
                results_list.append(f"操作执行成功")
        logger.info(f"已补充预期结果，使数量与步骤一致")
    else:
        # 预期结果多，步骤少：合并预期结果
        # 将多余的预期结果合并到最后一条
        if len(results_list) > len(steps_list):
            merged_results = results_list[:len(steps_list)]
            # 将多余的预期结果合并到最后一条
            extra_results = results_list[len(steps_list):]
            if extra_results and merged_results:
                merged_results[-1] = merged_results[-1] + "；" + "；".join(extra_results)
            results_list = merged_results
            logger.info(f"已合并多余预期结果，使数量与步骤一致")
    
    # 重新生成格式化的步骤和预期结果
    new_steps = _format_numbered_items(steps_list)
    new_results = _format_numbered_items(results_list)
    
    # 更新用例
    if "steps" in case:
        case["steps"] = new_steps
    if "expectedResults" in case:
        case["expectedResults"] = new_results
    if "步骤描述" in case:
        case["步骤描述"] = new_steps
    if "预期结果" in case:
        case["预期结果"] = new_results
    
    return case


def _parse_numbered_items(text: str) -> List[str]:
    """解析带编号的项目列表"""
    if not text:
        return []
    
    # 分割成行
    lines = text.strip().split('\n')
    items = []
    
    for line in lines:
        line = line.strip()
        if not line:
            continue
        # 移除编号 #1. #2. 等
        cleaned = re.sub(r'^#\d+\.\s*', '', line)
        if cleaned:
            items.append(cleaned)
    
    return items


def _format_numbered_items(items: List[str]) -> str:
    """格式化为带编号的项目列表"""
    formatted = []
    for i, item in enumerate(items, 1):
        formatted.append(f"#{i}. {item}")
    return '\n'.join(formatted)


def _validate_all_test_cases(test_cases: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """校验并修复所有测试用例"""
    fixed_count = 0
    for i, case in enumerate(test_cases):
        original = json.dumps(case, ensure_ascii=False)
        fixed_case = _validate_and_fix_test_case(case)
        if json.dumps(fixed_case, ensure_ascii=False) != original:
            fixed_count += 1
        test_cases[i] = fixed_case
    
    if fixed_count > 0:
        logger.info(f"共修复了 {fixed_count} 条测试用例的步骤与预期结果对应关系")
    
    return test_cases


def _extract_json_from_response(content: str) -> Dict[str, Any]:
    """从LLM响应中提取JSON"""
    json_pattern = r'```json\s*([\s\S]*?)\s*```'
    matches = re.findall(json_pattern, content)
    
    if matches:
        try:
            return json.loads(matches[0])
        except json.JSONDecodeError:
            pass
    
    try:
        return json.loads(content)
    except json.JSONDecodeError:
        pass
    
    json_obj_pattern = r'\{[\s\S]*\}'
    match = re.search(json_obj_pattern, content)
    if match:
        try:
            return json.loads(match.group())
        except json.JSONDecodeError:
            pass
    
    return {}


def _normalize_test_case(case: Dict[str, Any]) -> Dict[str, Any]:
    """将测试用例字段名统一为英文字段名"""
    field_mapping = {
        "一级模块": "level1Module",
        "二级模块": "level2Module",
        "三级模块": "level3Module",
        "四级模块": "level4Module",
        "用例名称": "caseName",
        "优先级": "priority",
        "用例类型": "caseType",
        "前置条件": "preconditions",
        "步骤描述": "steps",
        "预期结果": "expectedResults",
        "备注": "remarks",
        "维护人": "maintainer",
        "适用场景": "applicableScenario",
        "用例类别": "caseCategory"
    }
    
    normalized = {}
    for key, value in case.items():
        if key in field_mapping:
            normalized[field_mapping[key]] = value
        else:
            normalized[key] = value
    
    # 设置默认值
    normalized.setdefault("level3Module", "")
    normalized.setdefault("level4Module", "")
    normalized.setdefault("remarks", "")
    normalized.setdefault("maintainer", "测试工程师")
    normalized.setdefault("applicableScenario", "定制-新增需求类（功能、中控...）")
    normalized.setdefault("caseCategory", "软件功能")
    
    return normalized


def _generate_excel(test_cases: List[Dict[str, Any]]) -> str:
    """生成Excel文件并上传，返回URL"""
    try:
        import pandas as pd
    except ImportError:
        # 如果没有pandas，安装
        import subprocess
        subprocess.run(["pip", "install", "pandas", "openpyxl"], check=True)
        import pandas as pd
    
    if not test_cases:
        raise Exception("测试用例列表为空")
    
    # JSON字段名到Excel中文列名的映射
    field_mapping = {
        "level1Module": "一级模块",
        "level2Module": "二级模块",
        "level3Module": "三级模块",
        "level4Module": "四级模块",
        "caseName": "用例名称",
        "priority": "优先级",
        "caseType": "用例类型",
        "preconditions": "前置条件",
        "steps": "步骤描述",
        "expectedResults": "预期结果",
        "remarks": "备注",
        "maintainer": "维护人",
        "applicableScenario": "适用场景",
        "caseCategory": "用例类别"
    }
    
    # 定义Excel列顺序
    columns = [
        "一级模块", "二级模块", "三级模块", "四级模块",
        "用例名称", "优先级", "用例类型", "前置条件",
        "步骤描述", "预期结果", "备注", "维护人", "适用场景", "用例类别"
    ]
    
    # 将JSON字段名转换为中文列名
    converted_cases = []
    for case in test_cases:
        converted_case = {}
        for eng_field, cn_field in field_mapping.items():
            converted_case[cn_field] = case.get(eng_field, "")
        converted_cases.append(converted_case)
    
    # 创建DataFrame
    df = pd.DataFrame(converted_cases)
    
    # 按照模板列顺序排列
    df = df[columns]
    
    # 生成临时文件
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"test_cases_{timestamp}.xlsx"
    temp_path = os.path.join(tempfile.gettempdir(), filename)
    
    # 保存Excel文件
    with pd.ExcelWriter(temp_path, engine='openpyxl') as writer:
        df.to_excel(writer, sheet_name='测试用例', index=False)
        
        # 调整列宽
        worksheet = writer.sheets['测试用例']
        for idx, col in enumerate(df.columns, 1):
            try:
                col_data = df[col]
                if len(col_data) > 0:
                    str_lens = [len(str(v)) for v in col_data]
                    max_len = max(str_lens) if str_lens else 0
                else:
                    max_len = 0
                max_length = max(max_len, len(str(col)))
                max_length = min(max_length + 2, 50)
                col_letter = chr(64 + idx) if idx <= 26 else 'A' + chr(64 + idx - 26)
                worksheet.column_dimensions[col_letter].width = max_length
            except Exception:
                pass
    
    # 上传到对象存储
    storage = S3SyncStorage(
        endpoint_url=os.getenv("COZE_BUCKET_ENDPOINT_URL"),
        access_key="",
        secret_key="",
        bucket_name=os.getenv("COZE_BUCKET_NAME"),
        region="cn-beijing",
    )
    
    with open(temp_path, 'rb') as f:
        file_content = f.read()
    
    object_key = storage.upload_file(
        file_content=file_content,
        file_name=filename,
        content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )
    
    # 生成预签名URL
    signed_url = storage.generate_presigned_url(key=object_key, expire_time=3600)
    
    return signed_url


def test_case_generation_node(
    state: TestCaseGenerationInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> TestCaseGenerationOutput:
    """
    title: 测试用例生成
    desc: 根据PRD文档生成测试用例Excel文件，自动校验并修复步骤与预期结果对应关系
    integrations: test-case-generator, storage
    """
    ctx = runtime.context
    
    # 处理输入：支持文件上传和文本内容两种方式
    prd_content = ""
    if state.prd_document:
        # 文件上传方式（独立测试时）
        from utils.file.file import FileOps
        prd_content = FileOps.extract_text(state.prd_document)
    elif state.prd_content:
        # 文本内容方式（工作流连接时）
        prd_content = state.prd_content
    else:
        raise ValueError("请提供PRD文件或PRD内容")
    
    # 从配置文件读取SP和UP
    cfg_path = os.path.join(os.getenv("COZE_WORKSPACE_PATH", ""), "config", "test_case_generation_llm_cfg.json")
    try:
        with open(cfg_path, 'r', encoding='utf-8') as f:
            cfg = json.load(f)
        llm_config = cfg.get("config", {})
        sp = cfg.get("sp", "")
        up = cfg.get("up", "")
    except Exception as e:
        logger.error(f"读取配置文件失败: {e}")
        llm_config = {
            "model": "doubao-seed-2-0-pro-260215",
            "temperature": 0.5,
            "max_completion_tokens": 32768
        }
        sp = ""
        up = ""
    
    # 使用jinja2渲染用户提示词
    up_tpl = Template(up)
    user_prompt = up_tpl.render({"prd_content": prd_content})
    
    # 调用大模型生成测试用例
    client = LLMClient(ctx=ctx)
    
    messages = [
        SystemMessage(content=sp),
        HumanMessage(content=user_prompt)
    ]
    
    response = client.invoke(
        messages=messages,
        model=llm_config.get("model", "doubao-seed-2-0-pro-260215"),
        temperature=llm_config.get("temperature", 0.5),
        max_completion_tokens=llm_config.get("max_completion_tokens", 32768)
    )
    
    # 处理响应内容
    response_content = response.content
    if isinstance(response_content, list):
        text_parts = []
        for item in response_content:
            if isinstance(item, dict) and item.get("type") == "text":
                text_parts.append(item.get("text", ""))
            elif isinstance(item, str):
                text_parts.append(item)
        response_content = "\n".join(text_parts)
    
    logger.info(f"LLM响应长度: {len(str(response_content))}")
    
    # 提取JSON结果
    result = _extract_json_from_response(str(response_content))
    
    # 提取PRD分析结果（用于日志记录）
    prd_analysis = result.get("prd_analysis", {})
    if prd_analysis:
        logger.info(f"PRD分析结果：功能清单 {len(prd_analysis.get('功能清单', []))} 项，"
                   f"正常场景 {prd_analysis.get('正常场景数', 0)} 个，"
                   f"异常场景 {prd_analysis.get('异常场景数', 0)} 个，"
                   f"边界场景 {prd_analysis.get('边界场景数', 0)} 个")
    
    # 获取测试用例列表
    test_cases = []
    if "testCases" in result:
        test_cases = result["testCases"]
    elif "test_cases" in result:
        test_cases = result["test_cases"]
    
    if not test_cases:
        logger.error("未能从LLM响应中提取测试用例")
        raise Exception("生成测试用例失败：LLM响应中未包含有效的测试用例数据")
    
    # 标准化字段名（中文->英文）
    test_cases = [_normalize_test_case(case) for case in test_cases]
    
    # 校验并修复步骤与预期结果对应关系
    test_cases = _validate_all_test_cases(test_cases)
    
    # 记录用例统计
    summary = result.get("summary", {})
    logger.info(f"成功生成 {len(test_cases)} 条测试用例 "
               f"(P1:{summary.get('p1_count', 0)}, P2:{summary.get('p2_count', 0)}, "
               f"P3:{summary.get('p3_count', 0)})")
    
    # 生成Excel文件
    excel_url = _generate_excel(test_cases)
    
    return TestCaseGenerationOutput(
        test_cases=test_cases,
        test_case_excel_url=excel_url
    )
