"""
测试用例完善节点 - 根据评估报告建议完善测试用例
"""
import os
import json
import re
import tempfile
import logging
from datetime import datetime
from typing import Dict, Any, List
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from coze_coding_dev_sdk import LLMClient
from coze_coding_dev_sdk.s3 import S3SyncStorage
from langchain_core.messages import SystemMessage, HumanMessage
from jinja2 import Template
from graphs.state import TestCaseRefinementInput, TestCaseRefinementOutput

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def _extract_json_from_response(content: str) -> Dict[str, Any]:
    """从LLM响应中提取JSON"""
    json_pattern = r'```json\s*([\s\S]*?)\s*```'
    matches = re.findall(json_pattern, content)
    
    if matches:
        try:
            return json.loads(matches[0])
        except json.JSONDecodeError:
            pass
    
    try:
        return json.loads(content)
    except json.JSONDecodeError:
        pass
    
    json_obj_pattern = r'\{[\s\S]*\}'
    match = re.search(json_obj_pattern, content)
    if match:
        try:
            return json.loads(match.group())
        except json.JSONDecodeError:
            pass
    
    return {}


def _validate_test_case(case: Dict[str, Any]) -> Dict[str, Any]:
    """校验并修复单个测试用例"""
    steps = case.get("steps", "")
    expected = case.get("expectedResults", "")
    
    # 统计步骤和预期结果的数量
    step_count = len(re.findall(r'#\d+\.', steps))
    expected_count = len(re.findall(r'#\d+\.', expected))
    
    # 如果数量不匹配，尝试修复
    if step_count > 0 and step_count != expected_count:
        # 将预期结果拆分成列表
        expected_items = re.split(r'#\d+\.\s*', expected)
        expected_items = [item.strip() for item in expected_items if item.strip()]
        
        # 补齐预期结果
        while len(expected_items) < step_count:
            expected_items.append("系统正常响应")
        
        # 重新格式化预期结果
        fixed_expected = []
        for i, item in enumerate(expected_items[:step_count], 1):
            fixed_expected.append(f"#{i}. {item}")
        
        case["expectedResults"] = "\n".join(fixed_expected)
        logger.warning(f"修复测试用例 '{case.get('caseName', '')}' 的预期结果数量：{expected_count} -> {step_count}")
    
    return case


def _generate_excel(test_cases: List[Dict[str, Any]]) -> str:
    """生成Excel文件并上传，返回URL"""
    try:
        import pandas as pd
    except ImportError:
        import subprocess
        subprocess.run(["pip", "install", "pandas", "openpyxl"], check=True)
        import pandas as pd
    
    if not test_cases:
        raise Exception("测试用例列表为空")
    
    # JSON字段名到Excel中文列名的映射
    field_mapping = {
        "level1Module": "一级模块",
        "level2Module": "二级模块",
        "level3Module": "三级模块",
        "level4Module": "四级模块",
        "caseName": "用例名称",
        "priority": "优先级",
        "caseType": "用例类型",
        "preconditions": "前置条件",
        "steps": "步骤描述",
        "expectedResults": "预期结果",
        "remarks": "备注",
        "maintainer": "维护人",
        "applicableScenario": "适用场景",
        "caseCategory": "用例类别"
    }
    
    # 定义Excel列顺序
    columns = [
        "一级模块", "二级模块", "三级模块", "四级模块",
        "用例名称", "优先级", "用例类型", "前置条件",
        "步骤描述", "预期结果", "备注", "维护人", "适用场景", "用例类别"
    ]
    
    # 将JSON字段名转换为中文列名
    converted_cases = []
    for case in test_cases:
        converted_case = {}
        for eng_field, cn_field in field_mapping.items():
            converted_case[cn_field] = case.get(eng_field, "")
        converted_cases.append(converted_case)
    
    # 创建DataFrame
    df = pd.DataFrame(converted_cases)
    
    # 按照模板列顺序排列
    df = df[columns]
    
    # 生成临时文件
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"refined_test_cases_{timestamp}.xlsx"
    temp_path = os.path.join(tempfile.gettempdir(), filename)
    
    # 保存Excel文件
    with pd.ExcelWriter(temp_path, engine='openpyxl') as writer:
        df.to_excel(writer, sheet_name='测试用例', index=False)
        
        # 调整列宽
        worksheet = writer.sheets['测试用例']
        for idx, col in enumerate(df.columns, 1):
            try:
                col_data = df[col]
                if len(col_data) > 0:
                    str_lens = [len(str(v)) for v in col_data]
                    max_len = max(str_lens) if str_lens else 0
                else:
                    max_len = 0
                max_length = max(max_len, len(str(col)))
                max_length = min(max_length + 2, 50)
                col_letter = chr(64 + idx) if idx <= 26 else 'A' + chr(64 + idx - 26)
                worksheet.column_dimensions[col_letter].width = max_length
            except Exception:
                pass
    
    # 上传到对象存储
    storage = S3SyncStorage(
        endpoint_url=os.getenv("COZE_BUCKET_ENDPOINT_URL"),
        access_key="",
        secret_key="",
        bucket_name=os.getenv("COZE_BUCKET_NAME"),
        region="cn-beijing",
    )
    
    with open(temp_path, 'rb') as f:
        file_content = f.read()
    
    object_key = storage.upload_file(
        file_content=file_content,
        file_name=filename,
        content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )
    
    # 生成预签名URL
    signed_url = storage.generate_presigned_url(key=object_key, expire_time=3600)
    
    return signed_url


def test_case_refinement_node(
    state: TestCaseRefinementInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> TestCaseRefinementOutput:
    """
    title: 测试用例完善
    desc: 根据测试用例评估报告的建议完善测试用例，只进行1轮完善
    integrations: llm, storage
    """
    ctx = runtime.context
    
    # 从测试用例生成配置文件读取SP和UP（使用相同的技能和逻辑规则）
    cfg_path = os.path.join(os.getenv("COZE_WORKSPACE_PATH", ""), "config", "test_case_generation_llm_cfg.json")
    try:
        with open(cfg_path, 'r', encoding='utf-8') as f:
            cfg = json.load(f)
        llm_config = cfg.get("config", {})
        sp = cfg.get("sp", "")
        up = cfg.get("up", "")
    except Exception as e:
        logger.error(f"读取配置文件失败: {e}")
        llm_config = {
            "model": "doubao-seed-2-0-pro-260215",
            "temperature": 0.3,
            "max_completion_tokens": 32768
        }
        sp = ""
        up = ""
    
    # 使用jinja2渲染用户提示词，增加评估报告作为改进依据
    # 注意：虽然使用test_case_generation_llm_cfg.json的规则，但这是完善场景
    refinement_up = """请按照以下流程完善测试用例：

## ═══════════════════════════════════════════════════════════════════
## 背景说明
## ═══════════════════════════════════════════════════════════════════

本任务是**测试用例完善**，而非全新生成。已有一份测试用例经过质量评估，评估分数为**{{evaluation_score}}分**，需要根据评估报告的建议进行针对性改进。

## ═══════════════════════════════════════════════════════════════════
## 输入信息
## ═══════════════════════════════════════════════════════════════════

### 原始测试用例
```json
{{test_cases}}
```

### 质量评估分数
{{evaluation_score}}分

### 质量评估报告
{{evaluation_report}}

### 修改建议
{{modification_suggestions}}

### PRD文档内容（用于参考）
{{prd_content}}

## ═══════════════════════════════════════════════════════════════════
## 完善流程（必须严格遵循测试用例生成规则）
## ═══════════════════════════════════════════════════════════════════

### 第一步：深度分析PRD文档
按照测试用例生成规则，完成以下分析：
1. **功能清单提取**：提取所有功能点，记录触发条件、操作步骤、业务规则、预期结果
2. **业务规则深度分析**：分析数值边界、格式约束、时限约束、次数限制、权限控制
3. **场景识别**：识别所有正常场景、异常场景、边界场景
4. **非功能需求分析**：分析性能要求、安全要求、兼容性要求
5. **数据需求分析**：分析字段约束、唯一性要求、默认值

### 第二步：分析评估报告问题
根据评估报告，识别需要改进的问题：
1. **完整性问题**：缺失的功能点、缺失的测试场景
2. **有效性问题**：冗余用例、缺乏针对性
3. **规范性问题**：步骤与预期结果不匹配、前置条件格式错误
4. **针对性问题**：优先级划分不合理、高风险场景覆盖不足
5. **可执行性问题**：步骤不清晰、预期结果不明确
6. **可维护性问题**：冗余用例、依赖关系不清晰
7. **数据适配性问题**：边界数据不足、数据示例不完整

### 第三步：针对性完善测试用例
根据分析结果，对测试用例进行以下改进：

1. **补充缺失场景**：
   - 根据PRD分析结果补充缺失的功能点测试用例
   - 补充缺失的异常场景和边界场景
   - 补充性能测试、安全测试、兼容性测试用例

2. **修正格式问题**：
   - 修正步骤与预期结果数量不匹配的问题（**必须一一对应**）
   - 修正前置条件格式（多个条件使用换行编号）
   - 确保步骤描述清晰、预期结果明确

3. **优化用例名称**：
   - 格式：[模块/功能]-[条件/场景][功能描述][预期结果]
   - 简洁明了，20-30字以内
   - 去数据化，不包含具体测试数据

4. **调整优先级**：
   - 核心功能用例设为P1
   - 重要功能用例设为P2
   - 次要功能用例设为P3

5. **保留原有优点**：
   - 保留原始测试用例中的合理设计
   - 保留有效的测试场景和数据

## ═══════════════════════════════════════════════════════════════════
## 【硬性规则】（来自测试用例生成规范）
## ═══════════════════════════════════════════════════════════════════

1. **步骤数量 = 预期结果数量**（不可违反）
   - 步骤描述使用 #1. #2. #3. 格式编号
   - 预期结果使用 #1. #2. #3. 格式编号
   - 每个操作步骤必须有且仅有一个对应的预期结果

2. **三级模块、四级模块不是场景类型名称**（不涉及则留空）
   - 三级模块、四级模块必须是功能模块名称
   - 场景类型（正常场景、异常场景、边界场景）应在"用例类别"字段中体现

3. **多个前置条件使用换行编号格式**（1. xxx\\n2. xxx）
   - 单个前置条件：直接描述，无需编号
   - 多个前置条件：使用"1. "、"2. "编号，每个条件占一行

4. **用例名称符合命名规范**
   - 格式：[模块]-[条件][功能][结果]
   - 简洁明了，20-30字以内
   - 去数据化，不包含具体测试数据

## ═══════════════════════════════════════════════════════════════════
## 输出格式
## ═══════════════════════════════════════════════════════════════════

必须输出以下JSON结构(包含在```json代码块中)：
```json
{
  "refinedTestCases": [
    {
      "level1Module": "模块名",
      "level2Module": "子模块名",
      "level3Module": "",
      "level4Module": "",
      "caseName": "模块-条件场景功能结果",
      "priority": "P1",
      "caseType": "功能测试",
      "preconditions": "1. 前置条件1\\n2. 前置条件2",
      "steps": "#1.第一步操作\\n#2.第二步操作\\n#3.第三步操作",
      "expectedResults": "#1.第一步预期结果\\n#2.第二步预期结果\\n#3.第三步预期结果",
      "remarks": "",
      "caseCategory": "软件功能"
    }
  ],
  "refinementSummary": {
    "original_count": 原始用例数量,
    "refined_count": 完善后用例数量,
    "added_count": 新增用例数量,
    "modified_count": 修改用例数量,
    "key_improvements": ["关键改进1", "关键改进2", ...]
  }
}
```

## ═══════════════════════════════════════════════════════════════════
## 输出前最终检查清单
## ═══════════════════════════════════════════════════════════════════

在输出JSON之前，必须逐条确认：
- [ ] 已根据PRD深度分析补充缺失场景
- [ ] 已根据评估报告修正问题
- [ ] 已修正所有步骤与预期结果数量不匹配的问题
- [ ] 所有用例的三级模块、四级模块不是场景类型名称
- [ ] 所有用例的前置条件格式正确（多条件换行编号）
- [ ] 所有用例的名称符合命名规范（格式统一、简洁明了、去数据化、20-30字）
- [ ] 用例1：步骤数量 = 预期结果数量
- [ ] 用例2：步骤数量 = 预期结果数量
- [ ] ... 检查所有用例

如果发现任何不匹配，立即修正后再输出！
"""
    
    up_tpl = Template(refinement_up)
    user_prompt = up_tpl.render({
        "test_cases": json.dumps(state.test_cases, ensure_ascii=False, indent=2),
        "evaluation_score": state.test_case_evaluation_score,
        "evaluation_report": state.test_case_evaluation_report,
        "modification_suggestions": state.test_case_modification_suggestions,
        "prd_content": state.prd_content
    })
    
    # 调用大模型完善测试用例
    client = LLMClient(ctx=ctx)
    
    messages = [
        SystemMessage(content=sp),
        HumanMessage(content=user_prompt)
    ]
    
    response = client.invoke(
        messages=messages,
        model=llm_config.get("model", "doubao-seed-2-0-pro-260215"),
        temperature=llm_config.get("temperature", 0.3),
        max_completion_tokens=llm_config.get("max_completion_tokens", 32768)
    )
    
    # 处理响应内容
    response_content = response.content
    if isinstance(response_content, list):
        text_parts = []
        for item in response_content:
            if isinstance(item, dict) and item.get("type") == "text":
                text_parts.append(item.get("text", ""))
            elif isinstance(item, str):
                text_parts.append(item)
        response_content = "\n".join(text_parts)
    
    logger.info(f"LLM响应长度: {len(str(response_content))}")
    
    # 提取JSON结果
    result = _extract_json_from_response(str(response_content))
    
    # 获取完善后的测试用例列表
    refined_test_cases = result.get("refinedTestCases", [])
    if not refined_test_cases:
        logger.error("未能从LLM响应中提取完善后的测试用例")
        raise Exception("完善测试用例失败：LLM响应中未包含有效的测试用例数据")
    
    # 校验并修复所有测试用例
    refined_test_cases = [_validate_test_case(case) for case in refined_test_cases]
    
    logger.info(f"成功完善 {len(refined_test_cases)} 条测试用例")
    
    # 生成Excel文件
    refined_excel_url = _generate_excel(refined_test_cases)
    
    return TestCaseRefinementOutput(
        refined_test_cases=refined_test_cases,
        refined_test_case_excel_url=refined_excel_url,
        refinement_count=1
    )
