"""
测试用例分数判断节点 - 判断测试用例质量评估分数是否需要完善
"""
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from graphs.state import CheckTestCaseScoreInput, CheckTestCaseScoreOutput


def check_test_case_score_node(
    state: CheckTestCaseScoreInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> CheckTestCaseScoreOutput:
    """
    title: 测试用例分数判断
    desc: 判断测试用例质量评估分数是否≥90分，<90分且未完善过则进入完善流程，只进行1轮完善
    """
    ctx = runtime.context
    
    score = state.test_case_evaluation_score
    refinement_count = state.refinement_count
    
    # 判断逻辑：分数<90分 且 未进行过完善（refinement_count==0）
    need_refinement = score < 90 and refinement_count == 0
    
    if need_refinement:
        branch_result = "需要完善"
    else:
        branch_result = "输出测试用例"
    
    return CheckTestCaseScoreOutput(
        need_refinement=need_refinement,
        branch_result=branch_result
    )
