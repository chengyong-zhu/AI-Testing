"""
PRD分数判断节点 - 判断PRD评估分数是否通过准入阈值
"""
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from graphs.state import CheckPrdScoreInput, CheckPrdScoreOutput


def check_prd_score_node(
    state: CheckPrdScoreInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> CheckPrdScoreOutput:
    """
    title: PRD分数判断
    desc: 判断PRD评估分数是否达到准入阈值(≥80分)，决定后续流程分支
    """
    ctx = runtime.context
    
    # 判断是否通过准入，branch_result 必须与 path_map 的 key 一致
    if state.prd_evaluation_score >= 80:
        branch_result = "进入测试用例生成"
    else:
        branch_result = "PRD未通过准入"
    
    return CheckPrdScoreOutput(branch_result=branch_result)
