"""
PRD测试准入质量评估节点 - 使用prd-test-quality-assessment技能进行质量评估
严格按照PRD测试准入质量评估报告模板.json格式输出
"""
import os
import json
import re
import tempfile
from datetime import datetime
from typing import Dict, Any, List
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from coze_coding_dev_sdk import LLMClient
from coze_coding_dev_sdk.s3 import S3SyncStorage
from langchain_core.messages import SystemMessage, HumanMessage
from graphs.state import PrdEvaluationInput, PrdEvaluationOutput


# PRD测试准入评估标准系统提示词
PRD_EVALUATION_SP = """# 角色定义
你是PRD测试准入质量评估专家，专注于产品需求文档的质量评估与测试准入判断。

# 评估标准

## 一、评分维度与权重（总分100分）
### 文档基础（25分）
- 1.1 版本信息（8分）：版本号(2分)、修订记录-内容(3分)、修订记录-格式(1分)、术语定义(1分)、术语表(1分)
- 1.2 结构清晰（9分）：层级分明(3分)、无歧义(3分)、无矛盾(3分)
- 1.3 背景目标明确（8分）：需求背景(3分)、需求目标(3分)、业务边界(2分)

### 功能需求（30分）
- 2.1 功能点可验证（12分）：触发条件(3分)、操作步骤(3分)、业务规则(3分)、预期结果(3分)
- 2.2 业务规则边界（10分）：核心规则(3分)、边界条件-数值(2分)、边界条件-权限(2分)、边界条件-格式(3分)
- 2.3 异常场景（8分）：网络异常(3分)、数据文件异常(2分)、权限异常(2分)、提示信息(1分)

### 非功能需求（25分）
**评估规则**：非功能需求各子维度需满足触发条件才进行详细评估，否则按满分处理并计入总分。

- 3.1 性能指标（7分）
  - **触发条件**：文档明确提到具体的性能指标参数（响应时间≤X秒、并发量X、吞吐量X、文件大小限制X等具体数值）
  - **触发后**：按检查项逐项评估，扣分制
  - **未触发**：给满分7分，标记"不涉及（文档未提明确性能指标），给满分"
  
- 3.2 兼容性（6分）
  - **触发条件**：文档明确提到兼容性要求（操作系统版本、浏览器版本、设备适配等具体要求）
  - **触发后**：按检查项逐项评估，扣分制
  - **未触发**：给满分6分，标记"不涉及（文档未提兼容性要求），给满分"
  
- 3.3 易用性可靠性（7分）
  - **触发条件**：文档明确提到易用性可靠性要求（操作流程规范、错误提示规则、可用性指标、故障恢复机制等具体内容）
  - **触发后**：按检查项逐项评估，扣分制
  - **未触发**：给满分7分，标记"不涉及（文档未提易用性可靠性要求），给满分"
  
- 3.4 接口信息（5分）
  - **触发条件**：文档明确提到接口定义（接口地址、请求参数、返回参数、返回码等具体内容）
  - **触发后**：按检查项逐项评估，扣分制
  - **未触发**：给满分5分，标记"不涉及（文档未提接口定义），给满分"

### 数据需求（20分）
- 4.1 数据规则（20分）：数据类型(3分)、字段长度(2分)、约束条件(3分)、导入格式(2分)、导入校验(2分)、导出格式(2分)、迁移规则(3分)、数据处理(3分)

## 二、核心否决项（触发条件）
**重要说明**：核心否决项需满足特定触发条件才会进行检查，否则按"未触发"或"不适用"处理。

1. **术语歧义**：术语定义存在歧义，导致核心需求无法理解
2. **内容矛盾**：文档存在矛盾描述，或3处及以上歧义
3. **核心功能缺失**：核心功能点缺失或不可验证
4. **业务规则缺失**：核心业务规则缺失，**触发条件：业务规则不明确达6处及以上**
   - 统计规则：功能点中触发条件、操作步骤、预期结果等业务规则不明确的数量
   - 不足6处时标记为"未触发"
5. **性能无量化**：涉及性能场景但无任何量化指标，**触发条件：性能相关关键词达10处及以上**
   - 统计关键词：响应时间、延迟、并发量、吞吐量、TPS、QPS、处理时间、秒、毫秒、性能要求等
   - 不足10处时标记为"未触发"
6. **安全缺失**：涉及隐私场景无安全需求
7. **接口核心缺失**：有接口交互但核心参数/返回码缺失，**触发条件：接口相关关键词达10处及以上**
   - 统计关键词：接口、API、请求参数、返回参数、返回码、请求头、响应头、接口定义等
   - 不足10处时标记为"未触发"
8. **数据规则缺失**：数据密集场景核心存储规则缺失
9. **导入导出规则缺失**：**该项不进行检查，统一标记为"不适用"**

## 三、准入阈值
- ≥80分：准入测试
- 60-79分：整改后重审
- <60分：驳回

# 检查结果格式规范
- ✅ 符合：完全满足要求
- ⚠️ 轻微歧义：基本满足但有轻微问题
- ❌ 缺失：不满足要求
- N/A 不涉及：该项不适用

# 输出格式要求
严格按照以下JSON结构输出评估结果：

```json
{
  "评估概要": {
    "PRD名称": "产品需求文档完整名称",
    "PRD版本": "版本号(如V1.0)",
    "评估日期": "YYYY-MM-DD",
    "评估人": "质量评估系统",
    "需求范围": "核心需求点，用顿号分隔"
  },
  "评估结果总览": {
    "各维度得分": [
      {"维度": "文档基础", "满分": 25, "得分": 22, "得分率": "88%", "豁免状态": "正常评估"},
      {"维度": "功能需求", "满分": 30, "得分": 26, "得分率": "87%", "豁免状态": "正常评估"},
      {"维度": "非功能需求", "满分": 25, "得分": 25, "得分率": "100%", "豁免状态": "正常评估"},
      {"维度": "数据需求", "满分": 20, "得分": 20, "得分率": "100%", "豁免状态": "正常评估"},
      {"维度": "总分", "满分": 100, "得分": 93, "得分率": "93%", "豁免状态": "-"}
    ],
    "准入判断": "准入测试"
  },
  "维度判断与豁免说明": {
    "前言": "根据PRD内容分析，本次评估涉及的维度判断如下：",
    "文档基础维度": {
      "判断结果": "涉及，需评估",
      "判断依据": "文档包含版本信息、修订记录、背景目标等基础信息",
      "豁免状态": "不豁免"
    },
    "功能需求维度": {
      "判断结果": "涉及，需评估",
      "判断依据": "文档详细描述了5个功能点(F-01至F-05)",
      "豁免状态": "不豁免"
    },
    "非功能需求维度": {
      "判断结果": "涉及，需评估",
      "判断依据": [
        "性能指标：明确提到响应时间≤3秒、并发量5000等量化指标（触发评估）",
        "兼容性：明确提到iOS 12+、Android 8.0+、Chrome 90+等要求（触发评估）",
        "易用性可靠性：明确提到错误提示、用户引导等内容（触发评估）",
        "接口信息：未明确提到接口定义（不涉及，给满分5分）"
      ],
      "各子维度判断": {
        "性能指标": {"触发条件": "文档明确提到具体性能指标参数", "判断结果": "触发，需评估", "关键词": "响应时间≤3秒、并发量5000等"},
        "兼容性": {"触发条件": "文档明确提到兼容性要求", "判断结果": "触发，需评估", "关键词": "iOS 12+、Android 8.0+、Chrome 90+等"},
        "易用性可靠性": {"触发条件": "文档明确提到易用性可靠性要求", "判断结果": "触发，需评估", "关键词": "错误提示、用户引导等"},
        "接口信息": {"触发条件": "文档明确提到接口定义", "判断结果": "未触发，给满分", "得分": 5, "备注": "未提到接口相关内容，给满分5分，计入总分"}
      },
      "豁免状态": "不豁免"
    },
    "数据需求维度": {
      "判断结果": "涉及，需评估",
      "判断依据": [
        "数据存储相关关键词：数据库、表、字段、类型、长度、约束、主键、存储、保存等（多处）",
        "包含明确的\"数据需求\"章节（第4章）",
        "第4.1节定义了详细的数据字段表"
      ],
      "豁免状态": "不豁免"
    }
  },
  "核心否决项检查": {
    "检查结果": [
      {"否决项类型": "文档基础", "检查项": "术语歧义：术语定义存在歧义，导致核心需求无法理解", "检查结果": "未触发", "备注": "-"},
      {"否决项类型": "文档基础", "检查项": "内容矛盾：文档存在矛盾描述，或3处及以上歧义", "检查结果": "未触发", "备注": "-"},
      {"否决项类型": "功能需求", "检查项": "核心功能缺失：核心功能点缺失或不可验证", "检查结果": "未触发", "备注": "-"},
      {"否决项类型": "功能需求", "检查项": "业务规则缺失：核心业务规则缺失，触发条件：不明确规则达6处及以上", "检查结果": "未触发", "备注": "业务规则不明确共3处，未达触发阈值(6处)"},
      {"否决项类型": "非功能需求", "检查项": "性能无量化：涉及性能场景但无任何量化指标，触发条件：性能关键词达10处及以上", "检查结果": "未触发", "备注": "性能相关关键词共8处，未达触发阈值(10处)"},
      {"否决项类型": "非功能需求", "检查项": "安全缺失：涉及隐私场景无安全需求", "检查结果": "未触发", "备注": "-"},
      {"否决项类型": "接口/数据", "检查项": "接口核心缺失：有接口交互但核心参数/返回码缺失，触发条件：接口关键词达10处及以上", "检查结果": "未触发", "备注": "接口相关关键词共5处，未达触发阈值(10处)"},
      {"否决项类型": "接口/数据", "检查项": "数据规则缺失：数据密集场景核心存储规则缺失", "检查结果": "未触发", "备注": "-"},
      {"否决项类型": "接口/数据", "检查项": "导入导出规则缺失：该项不进行检查", "检查结果": "不适用", "备注": "根据评估规则，导入导出规则缺失项不再检查"}
    ],
    "核心否决项总结": "未触发任何核心否决项，可以继续进行各维度评估。"
  },
  "详细评估": {
    "文档基础评估": {
      "标题后缀": "（22/25分）",
      "1.1 版本信息": {
        "标题后缀": "（6/8分）",
        "检查结果": [
          {"检查项": "版本号", "满分标准": "文档有明确的版本号 (如v1.0.0)", "得分": 2, "检查结果": "✅ 符合"},
          {"检查项": "修订记录-内容", "满分标准": "修订记录包含版本号、修订日期、修订人、修订内容说明", "得分": 2, "检查结果": "⚠️ 轻微歧义"},
          {"检查项": "修订记录-格式", "满分标准": "修订记录表格格式规范，信息完整", "得分": 1, "检查结果": "✅ 符合"},
          {"检查项": "术语定义", "满分标准": "专业术语有明确解释", "得分": 0, "检查结果": "❌ 缺失"},
          {"检查项": "术语表", "满分标准": "术语表规范，无术语歧义或冲突", "得分": 1, "检查结果": "✅ 符合（无术语冲突）"}
        ],
        "评分": "6分（符合项：4/5，扣2分）",
        "问题描述": ["缺少专业术语定义章节"],
        "改进建议": ["建议增加\"术语定义\"章节，对专业术语进行明确定义"]
      },
      "1.2 结构清晰": {
        "标题后缀": "（8/9分）",
        "检查结果": [
          {"检查项": "层级分明", "满分标准": "文档结构清晰，层级分明(模块-子模块-功能点)", "得分": 3, "检查结果": "✅ 符合"},
          {"检查项": "无歧义", "满分标准": "需求描述清晰，无歧义", "得分": 2, "检查结果": "⚠️ 轻微歧义"},
          {"检查项": "无矛盾", "满分标准": "各章节之间无逻辑矛盾", "得分": 3, "检查结果": "✅ 符合"}
        ],
        "评分": "8分（符合项：2/3，部分符合：1/3，扣1分）",
        "问题描述": ["存在轻微歧义描述"],
        "改进建议": ["明确模糊描述"]
      },
      "1.3 背景目标明确": {
        "标题后缀": "（8/8分）",
        "检查结果": [
          {"检查项": "需求背景", "满分标准": "背景清晰说明业务场景和用户痛点", "得分": 3, "检查结果": "✅ 符合"},
          {"检查项": "需求目标", "满分标准": "目标明确、可衡量", "得分": 3, "检查结果": "✅ 符合"},
          {"检查项": "业务边界", "满分标准": "业务边界清晰，包含和排除的内容明确", "得分": 2, "检查结果": "✅ 符合"}
        ],
        "评分": "8分（全部符合）",
        "亮点": ["业务目标量化明确：注册转化率提升至50%+，注册失败率降至3%以下", "范围界定清晰：明确包含和不包含的功能"]
      },
      "文档基础总分": "22/25分（88%）"
    },
    "功能需求评估": {
      "标题后缀": "（26/30分）",
      "2.1 功能点可验证": {
        "标题后缀": "（10/12分）",
        "检查结果": [
          {"检查项": "触发条件", "满分标准": "每个功能点有明确的触发条件", "得分": 3, "检查结果": "✅ 符合"},
          {"检查项": "操作步骤", "满分标准": "操作步骤描述清晰、可执行", "得分": 2, "检查结果": "⚠️ 轻微歧义"},
          {"检查项": "业务规则", "满分标准": "业务规则描述明确", "得分": 3, "检查结果": "✅ 符合"},
          {"检查项": "预期结果", "满分标准": "预期结果量化、可判断", "得分": 2, "检查结果": "⚠️ 轻微歧义"}
        ],
        "评分": "10分（符合项：2/4，部分符合：2/4，扣2分）",
        "问题描述": ["部分操作步骤描述过于简化", "部分预期结果不够量化"],
        "改进建议": ["完善操作步骤的分支场景描述", "量化预期结果的具体要求"]
      },
      "2.2 业务规则边界": {
        "标题后缀": "（9/10分）",
        "检查结果": [
          {"检查项": "核心规则", "满分标准": "核心业务规则明确", "得分": 3, "检查结果": "✅ 符合"},
          {"检查项": "边界条件-数值", "满分标准": "最大值、最小值、空值等边界条件明确", "得分": 2, "检查结果": "✅ 符合"},
          {"检查项": "边界条件-权限", "满分标准": "权限控制清晰", "得分": 2, "检查结果": "✅ 符合"},
          {"检查项": "边界条件-格式", "满分标准": "参数范围、文件格式限制明确", "得分": 2, "检查结果": "⚠️ 轻微歧义"}
        ],
        "评分": "9分（符合项：3/4，部分符合：1/4，扣1分）",
        "问题描述": ["部分格式限制不够明确"],
        "改进建议": ["明确密码特殊字符范围", "补充第三方账号绑定的确认流程"]
      },
      "2.3 异常场景": {
        "标题后缀": "（7/8分）",
        "检查结果": [
          {"检查项": "网络异常", "满分标准": "网络异常处理定义 (超时、断网、弱网)", "得分": 3, "检查结果": "✅ 符合"},
          {"检查项": "数据文件异常", "满分标准": "数据文件异常处理定义 (格式错误、文件损坏、超大文件)", "得分": 2, "检查结果": "✅ 符合"},
          {"检查项": "权限异常", "满分标准": "权限异常处理定义 (无权限、权限不足)", "得分": 1, "检查结果": "⚠️ 轻微歧义"},
          {"检查项": "提示信息", "满分标准": "提示信息精准、友好", "得分": 1, "检查结果": "✅ 符合"}
        ],
        "评分": "7分（符合项：3/4，部分符合：1/4，扣1分）",
        "问题描述": ["权限异常场景处理不够详细"],
        "改进建议": ["补充权限不足时的具体处理逻辑和提示信息"]
      },
      "功能需求总分": "26/30分（87%）"
    },
    "非功能需求评估": {
      "标题后缀": "（25/25分）",
      "3.1 性能指标": {
        "标题后缀": "（7/7分）",
        "检查结果": [
          {"检查项": "响应时间", "满分标准": "关键操作响应时间量化(如≤2秒、≤500ms)", "得分": 3, "检查结果": "✅ 符合"},
          {"检查项": "数据处理能力", "满分标准": "数据处理能力量化 (如支持100万条记录)", "得分": 2, "检查结果": "✅ 符合"},
          {"检查项": "并发能力", "满分标准": "并发能力量化(如支持1000并发用户)", "得分": 1, "检查结果": "✅ 符合"},
          {"检查项": "文件大小限制", "满分标准": "数据文件大小限制明确", "得分": 1, "检查结果": "✅ 符合"}
        ],
        "评分": "7分（全部符合）",
        "亮点": ["性能指标全面且量化明确：验证码获取≤3秒、注册提交≤2秒、支持5000并发"]
      },
      "3.2 兼容性": {
        "标题后缀": "（6/6分）",
        "检查结果": [
          {"检查项": "操作系统", "满分标准": "操作系统兼容性明确 (如Windows 10+、macOS 11+)", "得分": 2, "检查结果": "✅ 符合"},
          {"检查项": "软硬件依赖", "满分标准": "硬件/软件依赖明确", "得分": 1, "检查结果": "✅ 符合"},
          {"检查项": "浏览器", "满分标准": "浏览器兼容性明确 (如Chrome 90+、Edge 90+)", "得分": 2, "检查结果": "✅ 符合"},
          {"检查项": "终端设备", "满分标准": "终端设备兼容性明确 (如支持某型号发射器)", "得分": 1, "检查结果": "✅ 符合"}
        ],
        "评分": "6分（全部符合）",
        "亮点": ["兼容性覆盖全面：iOS 12+、Android 8.0+、Chrome 90+、Safari 13+、Firefox 85+"]
      },
      "3.3 易用性可靠性": {
        "标题后缀": "（7/7分）",
        "检查结果": [
          {"检查项": "操作流程", "满分标准": "操作流程简化、用户引导清晰", "得分": 2, "检查结果": "✅ 符合"},
          {"检查项": "错误提示", "满分标准": "错误提示友好、可理解", "得分": 2, "检查结果": "✅ 符合"},
          {"检查项": "可用性指标", "满分标准": "系统可用性指标明确", "得分": 2, "检查结果": "✅ 符合"},
          {"检查项": "故障恢复", "满分标准": "故障恢复时间、数据备份要求明确", "得分": 1, "检查结果": "✅ 符合"}
        ],
        "评分": "7分（全部符合）",
        "亮点": ["系统可用性99.9%、故障恢复≤30分钟、每日数据备份"]
      },
      "3.4 接口信息": {
        "标题后缀": "（5/5分）",
        "检查结果": [
          {"检查项": "接口定义", "满分标准": "接口URL、请求方式明确", "得分": 2, "检查结果": "N/A 不涉及"},
          {"检查项": "请求参数", "满分标准": "请求参数完整(必填/选填、类型、约束)", "得分": 1, "检查结果": "N/A 不涉及"},
          {"检查项": "返回参数", "满分标准": "返回参数完整(字段含义、类型)", "得分": 1, "检查结果": "N/A 不涉及"},
          {"检查项": "返回码", "满分标准": "返回码定义清晰，提供示例", "得分": 1, "检查结果": "N/A 不涉及"}
        ],
        "评分": "5分（不涉及，给满分，计入总分）",
        "说明": ["文档未明确提到接口定义（如接口地址、请求参数、返回参数、返回码等），不涉及该维度，给满分5分并计入总分"]
      },
      "非功能需求总分": "25/25分（100%）"
    },
    "数据需求评估": {
      "标题后缀": "（20/20分）",
      "4.1 数据规则": {
        "标题后缀": "（20/20分）",
        "检查结果": [
          {"检查项": "数据类型", "满分标准": "数据类型明确(字符串、整数、浮点数、日期等)", "得分": 3, "检查结果": "✅ 符合"},
          {"检查项": "字段长度", "满分标准": "字段长度定义明确", "得分": 2, "检查结果": "✅ 符合"},
          {"检查项": "约束条件", "满分标准": "约束条件明确(主键、外键、唯一、非空等)", "得分": 3, "检查结果": "✅ 符合"},
          {"检查项": "导入格式", "满分标准": "导入文件格式明确 (Excel、CSV、JSON等)", "得分": 2, "检查结果": "N/A 不涉及"},
          {"检查项": "导入校验", "满分标准": "导入校验规则定义 (格式校验、业务校验)", "得分": 2, "检查结果": "N/A 不涉及"},
          {"检查项": "导出格式", "满分标准": "导出格式明确", "得分": 2, "检查结果": "N/A 不涉及"},
          {"检查项": "迁移规则(如有)", "满分标准": "数据迁移规则明确", "得分": 3, "检查结果": "✅ 符合"},
          {"检查项": "数据处理", "满分标准": "数据处理规则明确", "得分": 3, "检查结果": "✅ 符合"}
        ],
        "评分": "20分（符合项：5/8，不涉及项：3/8，按满分计算）",
        "亮点": ["第4.1节定义了详细的数据字段表", "明确密码BCrypt加密存储"]
      },
      "数据需求总分": "20/20分（100%）"
    }
  },
  "问题清单": {
    "检查结果": [
      {"检查项": "术语定义", "得分": "0/1", "问题描述": "缺少专业术语定义章节", "位置": "文档整体", "严重程度": "一般"},
      {"检查项": "操作步骤", "得分": "2/3", "问题描述": "部分操作步骤描述过于简化", "位置": "F-03", "严重程度": "一般"},
      {"检查项": "预期结果", "得分": "2/3", "问题描述": "部分预期结果不够量化", "位置": "F-05", "严重程度": "一般"}
    ],
    "问题统计": ["阻塞性问题：0个", "严重问题：0个", "一般问题：3个"]
  },
  "测试准入判断": {
    "准入条件检查": [
      {"检查项": "核心否决项检查", "结果": "✅ 通过（未触发任何核心否决项）"},
      {"检查项": "总分是否≥80分", "结果": "✅ 通过（93分）"}
    ],
    "准入结论": "该PRD整体质量优秀，总分93分，超过准入阈值（≥80分），可直接进入测试设计环节。"
  },
  "改进建议": {
    "优先级P0（必须整改，影响测试准入）": "无 - 本次评估未发现阻塞性问题，可直接准入测试。",
    "优先级P1（严重问题，建议整改后补充文档）": [],
    "优先级P2（一般问题，可在迭代中优化）": [
      {"问题名称": "缺少术语定义", "具体整改建议": "建议增加\"术语定义\"章节，对\"验证码\"、\"第三方授权\"、\"转化率\"等专业术语进行明确定义", "整改必要性": "提升文档可理解性，减少沟通成本"},
      {"问题名称": "部分操作步骤不够详细", "具体整改建议": "完善第三方注册的分支流程操作步骤，包括授权失败、用户取消授权等场景", "整改必要性": "确保测试用例覆盖所有场景"}
    ]
  },
  "总体结论与行动建议": {
    "总体评价": {
      "前言": "该PRD整体质量优秀，结构清晰，需求描述详尽，可直接进入测试设计环节。",
      "核心亮点": [
        "业务目标量化明确：注册转化率≥50%、注册失败率≤3%",
        "功能需求描述完整：覆盖5个核心功能点",
        "非功能需求全面：性能、兼容性、安全、易用性均有明确指标"
      ],
      "待改进点": [
        "缺少术语定义章节",
        "部分操作步骤和预期结果描述可进一步细化"
      ]
    },
    "行动建议": {
      "立即行动（准入测试）": [
        {"角色": "测试团队", "行动": "重点测试验证码逻辑、密码验证规则、第三方授权流程等核心功能；执行性能测试（验证码获取≤3秒、注册提交≤2秒、5000并发成功率≥99.9%）；执行兼容性测试（iOS 12+、Android 8.0+、Chrome 90+等）；执行安全性测试（HTTPS传输、密码加密、验证码防刷机制）"},
        {"角色": "开发团队", "行动": "参考PRD进行技术设计，重点关注第三方平台接口对接和短信服务商集成；补充接口文档（URL、请求参数、返回码等）；实现性能指标要求，进行压力测试验证"},
        {"角色": "产品团队", "行动": "监控上线后的数据指标：注册转化率（目标50%+）、注册失败率（目标≤3%）、日均注册量（目标增长40%）；收集用户反馈，为后续迭代优化做准备"}
      ],
      "短期优化（1-2周内）": [
        {"优化项": "补充可靠性指标", "具体要求": "产品团队补充系统可用性指标（如99.9%）；补充故障恢复时间（如≤30分钟）和数据备份策略", "执行方": "产品团队"},
        {"优化项": "完善业务规则边界", "具体要求": "明确第三方账号绑定状态是否支持解绑操作；明确密码是否允许特殊字符及范围；补充第三方账号绑定多个APP账号的确认流程", "执行方": "产品团队"}
      ],
      "中长期优化（后续迭代）": [
        {"优化项": "增加术语定义章节", "具体要求": "在PRD模板中增加术语定义章节；建立产品术语词典，统一团队认知", "执行方": "产品团队"},
        {"优化项": "完善分支场景描述", "具体要求": "建立标准的功能描述模板，覆盖正常流程和所有异常分支；提升PRD的完整性，减少测试过程中的疑问", "执行方": "产品团队"}
      ]
    }
  },
  "复查计划": {
    "复查时机": "建议在产品团队完成P1和P2优先级问题的整改后，进行PRD复查",
    "复查重点": ["系统可用性指标是否补充", "故障恢复和数据备份要求是否定义", "第三方账号解绑、密码特殊字符规则是否明确"],
    "复查方式": "由测试团队或质量评估团队对照检查清单进行复查"
  },
  "关键成功指标": {
    "前言": "建议产品团队和测试团队共同关注以下关键指标，验证本次PRD质量和产品实现效果：",
    "指标列表": [
      "测试覆盖度：测试用例覆盖度≥95%（基于PRD功能点）",
      "缺陷发现率：需求理解类缺陷占比≤10%（验证PRD质量）",
      "测试通过率：首轮测试通过率≥80%（验证需求完整性）",
      "上线指标达成率：注册转化率≥50%、注册失败率≤3%、日均注册量增长≥40%（验证业务目标）",
      "用户满意度：用户注册体验满意度≥4.5/5.0（验证用户体验）"
    ]
  },
  "报告尾部信息": {
    "评估报告生成时间": "YYYY-MM-DD HH:MM:SS",
    "评估报告版本": "V1.0",
    "评估有效期": "自评估之日起3个月内有效，如PRD有重大修订需重新评估"
  }
}
```"""


def _extract_json_from_response(content: str) -> Dict[str, Any]:
    """从LLM响应中提取JSON"""
    json_pattern = r'```json\s*([\s\S]*?)\s*```'
    matches = re.findall(json_pattern, content)
    
    if matches:
        try:
            return json.loads(matches[0])
        except json.JSONDecodeError:
            pass
    
    try:
        return json.loads(content)
    except json.JSONDecodeError:
        pass
    
    json_obj_pattern = r'\{[\s\S]*\}'
    match = re.search(json_obj_pattern, content)
    if match:
        try:
            return json.loads(match.group())
        except json.JSONDecodeError:
            pass
    
    return {}


def _get_check_icon(check_result: str) -> str:
    """根据检查结果获取图标"""
    if "✅" in check_result or "符合" in check_result and "不" not in check_result:
        return "✅"
    elif "⚠️" in check_result or "轻微" in check_result or "部分" in check_result:
        return "⚠️"
    elif "❌" in check_result or "缺失" in check_result:
        return "❌"
    elif "N/A" in check_result or "不涉及" in check_result:
        return "N/A"
    else:
        return "✅"


def _get_severity_style(severity: str) -> str:
    """根据严重程度获取样式"""
    if severity == "阻塞性":
        return "color: #C00000; font-weight: bold;"
    elif severity == "严重":
        return "color: #ED7D31; font-weight: bold;"
    else:
        return "color: #333;"


def _get_priority_style(priority: str) -> str:
    """根据优先级获取样式"""
    if "P0" in priority:
        return "color: #C00000; font-weight: bold;"
    elif "P1" in priority:
        return "color: #ED7D31; font-weight: bold;"
    else:
        return "color: #333;"


def _generate_html_report(result: Dict[str, Any]) -> str:
    """生成HTML报告，严格按照模板格式"""
    
    summary = result.get("评估概要", {})
    score_overview = result.get("评估结果总览", {})
    dim_judgment = result.get("维度判断与豁免说明", {})
    veto_checks = result.get("核心否决项检查", {}).get("检查结果", [])
    veto_summary = result.get("核心否决项检查", {}).get("核心否决项总结", "")
    detail_eval = result.get("详细评估", {})
    problem_list = result.get("问题清单", {}).get("检查结果", [])
    problem_stats = result.get("问题清单", {}).get("问题统计", [])
    admission = result.get("测试准入判断", {})
    suggestions = result.get("改进建议", {})
    conclusion_action = result.get("总体结论与行动建议", {})
    review_plan = result.get("复查计划", {})
    kpi = result.get("关键成功指标", {})
    footer_info = result.get("报告尾部信息", {})
    
    html = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>PRD质量评估报告</title>
    <style>
        @page {{ size: A4; margin: 1.5cm; }}
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{ font-family: "Microsoft YaHei", "SimSun", Arial, sans-serif; font-size: 10pt; line-height: 1.6; color: #333; }}
        .page {{ width: 210mm; padding: 15mm; background: white; }}
        .header {{ text-align: center; border-bottom: 2px solid #2E75B6; padding-bottom: 10px; margin-bottom: 15px; }}
        .header h1 {{ color: #2E75B6; font-size: 18pt; margin-bottom: 5px; }}
        table {{ width: 100%; border-collapse: collapse; margin: 8px 0; font-size: 9pt; }}
        th {{ background: #2E75B6; color: white; padding: 6px 8px; text-align: left; font-weight: bold; border: 1px solid #2E75B6; }}
        td {{ padding: 5px 8px; border: 1px solid #B4C6E7; vertical-align: top; }}
        tr:nth-child(even) {{ background: #F2F2F2; }}
        .section-title {{ color: #2E75B6; font-size: 12pt; font-weight: bold; margin: 12px 0 8px 0; }}
        .sub-section-title {{ color: #1F4E79; font-size: 10pt; font-weight: bold; margin: 8px 0 5px 0; }}
        .level1 {{ color: #2E75B6; font-size: 12pt; font-weight: bold; margin: 12px 0 8px 0; }}
        .level2 {{ color: #1F4E79; font-size: 10pt; font-weight: bold; margin: 8px 0 5px 0; }}
        .level3 {{ font-weight: bold; margin: 5px 0; }}
        ul, ol {{ margin: 5px 0 5px 25px; }}
        li {{ margin: 3px 0; }}
        .pass {{ color: #00B050; }}
        .warning {{ color: #ED7D31; }}
        .fail {{ color: #C00000; }}
        .na {{ color: #7F7F7F; }}
        .highlight {{ background: #E2EFDA; padding: 2px 5px; }}
        .footer {{ text-align: left; color: #333; font-size: 9pt; font-weight: bold; margin-top: 15px; padding-top: 10px; border-top: 1px solid #ddd; }}
    </style>
</head>
<body>
<div class="page">
    <div class="header">
        <h1>PRD测试准入质量评估报告</h1>
    </div>
"""
    
    # 一、评估概要
    html += """
    <div class="level1">一、评估概要</div>
    <table>
        <tr><th style="width:20%">项目</th><th style="width:80%">内容</th></tr>
"""
    html += f"        <tr><td>PRD名称</td><td>{summary.get('PRD名称', '-')}</td></tr>\n"
    html += f"        <tr><td>PRD版本</td><td>{summary.get('PRD版本', '-')}</td></tr>\n"
    html += f"        <tr><td>评估日期</td><td>{datetime.now().strftime('%Y-%m-%d')}</td></tr>\n"
    html += f"        <tr><td>评估人</td><td>{summary.get('评估人', '质量评估系统')}</td></tr>\n"
    html += f"        <tr><td>需求范围</td><td>{summary.get('需求范围', '-')}</td></tr>\n"
    html += "    </table>\n"
    
    # 二、评估结果总览
    html += """
    <div class="level1">二、评估结果总览</div>
    <table>
        <tr><th>维度</th><th>满分</th><th>得分</th><th>得分率</th><th>豁免状态</th></tr>
"""
    for dim in score_overview.get("各维度得分", []):
        html += f"        <tr><td>{dim.get('维度', '-')}</td><td>{dim.get('满分', 0)}</td><td>{dim.get('得分', 0)}</td><td>{dim.get('得分率', '0%')}</td><td>{dim.get('豁免状态', '-')}</td></tr>\n"
    html += "    </table>\n"
    html += f"    <p><strong>准入判断</strong>：{score_overview.get('准入判断', '-')}</p>\n"
    
    # 维度判断与豁免说明
    html += f"""
    <div class="level1">维度判断与豁免说明</div>
    <p>{dim_judgment.get('前言', '根据PRD内容分析，本次评估涉及的维度判断如下：')}</p>
"""
    for dim_name in ["文档基础维度", "功能需求维度", "非功能需求维度", "数据需求维度"]:
        dim_info = dim_judgment.get(dim_name, {})
        html += f"""
    <div class="level3">{dim_name}</div>
    <ul>
        <li><strong>判断结果</strong>：{dim_info.get('判断结果', '-')}</li>
        <li><strong>判断依据</strong>：
"""
        judgements = dim_info.get('判断依据', [])
        if isinstance(judgements, list):
            for j in judgements:
                html += f"<br/>◦ {j}"
        else:
            html += str(judgements)
        html += f"</li>\n        <li><strong>豁免状态</strong>：{dim_info.get('豁免状态', '-')}</li>\n    </ul>\n"
    
    # 核心否决项检查
    html += """
    <div class="level1">核心否决项检查</div>
    <table>
        <tr><th>否决项类型</th><th>检查项</th><th>检查结果</th><th>备注</th></tr>
"""
    for item in veto_checks:
        check_result = item.get("检查结果", "-")
        if "未触发" in check_result:
            result_class = "pass"
        elif "触发" in check_result:
            result_class = "fail"
        else:
            result_class = "na"
        html += f"        <tr><td>{item.get('否决项类型', '-')}</td><td>{item.get('检查项', '-')}</td><td class=\"{result_class}\">{check_result}</td><td>{item.get('备注', '-')}</td></tr>\n"
    html += f"    </table>\n    <p><strong>核心否决项总结</strong>：{veto_summary}</p>\n"
    
    # 详细评估
    html += '<div class="level1">详细评估</div>\n'
    
    dimension_configs = [
        ("文档基础评估", "一", 25),
        ("功能需求评估", "二", 30),
        ("非功能需求评估", "三", 25),
        ("数据需求评估", "四", 20)
    ]
    
    for dim_key, dim_num, dim_full in dimension_configs:
        dim_data = detail_eval.get(dim_key, {})
        if not dim_data:
            continue
        
        dim_score = dim_data.get("标题后缀", f"（0/{dim_full}分）")
        html += f'    <div class="level1">{dim_num}、{dim_key.replace("评估", "")}评估{dim_score}</div>\n'
        
        sub_dims = {
            "文档基础评估": [("1.1 版本信息", "版本信息", 8), ("1.2 结构清晰", "结构清晰", 9), ("1.3 背景目标明确", "背景目标明确", 8)],
            "功能需求评估": [("2.1 功能点可验证", "功能点可验证", 12), ("2.2 业务规则边界", "业务规则边界", 10), ("2.3 异常场景", "异常场景", 8)],
            "非功能需求评估": [("3.1 性能指标", "性能指标", 7), ("3.2 兼容性", "兼容性", 6), ("3.3 易用性可靠性", "易用性可靠性", 7), ("3.4 接口信息", "接口信息", 5)],
            "数据需求评估": [("4.1 数据规则", "数据规则", 20)]
        }
        
        for sub_key, sub_name, sub_full in sub_dims.get(dim_key, []):
            sub_data = dim_data.get(sub_key, {})
            if not sub_data:
                continue
            
            sub_score = sub_data.get("标题后缀", f"（0/{sub_full}分）")
            html += f'    <div class="level2">{sub_key}{sub_score}</div>\n'
            html += '    <table>\n        <tr><th>检查项</th><th>满分标准</th><th>得分</th><th>检查结果</th></tr>\n'
            
            for check in sub_data.get("检查结果", []):
                check_result = check.get("检查结果", "-")
                icon = _get_check_icon(check_result)
                if "✅" in icon:
                    result_class = "pass"
                elif "⚠️" in icon:
                    result_class = "warning"
                elif "❌" in icon:
                    result_class = "fail"
                else:
                    result_class = "na"
                html += f"        <tr><td>{check.get('检查项', '-')}</td><td>{check.get('满分标准', '-')}</td><td>{check.get('得分', 0)}</td><td class=\"{result_class}\">{icon} {check_result.replace('✅ ', '').replace('⚠️ ', '').replace('❌ ', '').replace('N/A ', '')}</td></tr>\n"
            
            html += "    </table>\n"
            
            # 评分
            if sub_data.get("评分"):
                html += f'    <p><strong>评分</strong>：{sub_data.get("评分")}</p>\n'
            
            # 问题描述
            if sub_data.get("问题描述"):
                html += '    <div class="level3">问题描述</div>\n    <ul>\n'
                for p in sub_data.get("问题描述", []):
                    html += f"        <li>{p}</li>\n"
                html += "    </ul>\n"
            
            # 改进建议
            if sub_data.get("改进建议"):
                html += '    <div class="level3">改进建议</div>\n    <ul>\n'
                for s in sub_data.get("改进建议", []):
                    html += f"        <li>{s}</li>\n"
                html += "    </ul>\n"
            
            # 亮点
            if sub_data.get("亮点"):
                html += '    <div class="level3">亮点</div>\n    <ul>\n'
                for h in sub_data.get("亮点", []):
                    html += f"        <li class=\"highlight\">{h}</li>\n"
                html += "    </ul>\n"
        
        # 维度总分
        if dim_data.get(f"{dim_key.replace('评估', '')}总分") or dim_data.get("文档基础总分") or dim_data.get("功能需求总分") or dim_data.get("非功能需求总分") or dim_data.get("数据需求总分"):
            total_key = f"{dim_key.replace('评估', '')}总分"
            if not dim_data.get(total_key):
                for key in ["文档基础总分", "功能需求总分", "非功能需求总分", "数据需求总分"]:
                    if dim_data.get(key):
                        total_key = key
                        break
            if dim_data.get(total_key):
                html += f'    <p><strong>{dim_key.replace("评估", "")}总分</strong>：{dim_data.get(total_key)}</p>\n'
    
    # 问题清单
    html += """
    <div class="level1">问题清单</div>
    <table>
        <tr><th>检查项</th><th>得分</th><th>问题描述</th><th>位置</th><th>严重程度</th></tr>
"""
    for item in problem_list:
        severity = item.get("严重程度", "一般")
        severity_style = _get_severity_style(severity)
        html += f"        <tr><td>{item.get('检查项', '-')}</td><td>{item.get('得分', '-')}</td><td>{item.get('问题描述', '-')}</td><td>{item.get('位置', '-')}</td><td style=\"{severity_style}\">{severity}</td></tr>\n"
    html += "    </table>\n"
    
    # 问题统计
    if problem_stats:
        html += '    <div class="level3">问题统计</div>\n    <ul>\n'
        for stat in problem_stats:
            html += f"        <li>{stat}</li>\n"
        html += "    </ul>\n"
    
    # 测试准入判断
    html += """
    <div class="level1">测试准入判断</div>
    <table>
        <tr><th>检查项</th><th>结果</th></tr>
"""
    for item in admission.get("准入条件检查", []):
        result = item.get("结果", "-")
        if "✅" in result:
            result_class = "pass"
        else:
            result_class = "fail"
        html += f"        <tr><td>{item.get('检查项', '-')}</td><td class=\"{result_class}\">{result}</td></tr>\n"
    html += "    </table>\n"
    html += f'    <p><strong>准入结论</strong>：{admission.get("准入结论", "-")}</p>\n'
    
    # 改进建议
    html += """
    <div class="level1">改进建议</div>
"""
    # P0
    p0 = suggestions.get("优先级P0（必须整改，影响测试准入）", "")
    html += f'    <div class="level2" style="color: #C00000;">优先级P0（必须整改，影响测试准入）</div>\n'
    html += f'    <p>{p0 if p0 else "无 - 本次评估未发现阻塞性问题，可直接准入测试。"}</p>\n'
    
    # P1
    p1_list = suggestions.get("优先级P1（严重问题，建议整改后补充文档）", [])
    html += '    <div class="level2" style="color: #ED7D31;">优先级P1（严重问题，建议整改后补充文档）</div>\n'
    if p1_list:
        html += '    <ol>\n'
        for item in p1_list:
            html += f'        <li><strong>{item.get("问题名称", "-")}</strong>：{item.get("具体整改建议", "-")}<br/><span style="color:#666;">整改必要性：{item.get("整改必要性", "-")}</span></li>\n'
        html += '    </ol>\n'
    else:
        html += '    <p>无</p>\n'
    
    # P2
    p2_list = suggestions.get("优先级P2（一般问题，可在迭代中优化）", [])
    html += '    <div class="level2">优先级P2（一般问题，可在迭代中优化）</div>\n'
    if p2_list:
        html += '    <ol>\n'
        for item in p2_list:
            html += f'        <li><strong>{item.get("问题名称", "-")}</strong>：{item.get("具体整改建议", "-")}<br/><span style="color:#666;">整改必要性：{item.get("整改必要性", "-")}</span></li>\n'
        html += '    </ol>\n'
    else:
        html += '    <p>无</p>\n'
    
    # 总体结论与行动建议
    overall_eval = conclusion_action.get("总体评价", {})
    html += """
    <div class="level1">总体结论与行动建议</div>
"""
    html += f'    <div class="level3">总体评价</div>\n    <p>{overall_eval.get("前言", "-")}</p>\n'
    
    # 核心亮点
    highlights = overall_eval.get("核心亮点", [])
    if highlights:
        html += '    <div class="level3">核心亮点</div>\n    <ul>\n'
        for h in highlights:
            html += f"        <li class=\"highlight\">{h}</li>\n"
        html += "    </ul>\n"
    
    # 待改进点
    improvements = overall_eval.get("待改进点", [])
    if improvements:
        html += '    <div class="level3">待改进点</div>\n    <ul>\n'
        for i in improvements:
            html += f"        <li>{i}</li>\n"
        html += "    </ul>\n"
    
    # 行动建议
    actions = conclusion_action.get("行动建议", {})
    if actions:
        html += '    <div class="level3">行动建议</div>\n'
        
        # 立即行动
        immediate = actions.get("立即行动（准入测试）", [])
        if immediate:
            html += '    <p><strong>立即行动（准入测试）</strong>：</p>\n    <ul>\n'
            for item in immediate:
                html += f"        <li><strong>{item.get('角色', '-')}</strong>：{item.get('行动', '-')}</li>\n"
            html += "    </ul>\n"
        
        # 短期优化
        short_term = actions.get("短期优化（1-2周内）", [])
        if short_term:
            html += '    <p><strong>短期优化（1-2周内）</strong>：</p>\n    <ul>\n'
            for item in short_term:
                html += f"        <li>{item.get('优化项', '-')}：{item.get('具体要求', '-')}（执行方：{item.get('执行方', '-')}）</li>\n"
            html += "    </ul>\n"
        
        # 中长期优化
        long_term = actions.get("中长期优化（后续迭代）", [])
        if long_term:
            html += '    <p><strong>中长期优化（后续迭代）</strong>：</p>\n    <ul>\n'
            for item in long_term:
                html += f"        <li>{item.get('优化项', '-')}：{item.get('具体要求', '-')}（执行方：{item.get('执行方', '-')}）</li>\n"
            html += "    </ul>\n"
    
    # 复查计划
    html += """
    <div class="level1">复查计划</div>
"""
    html += f'    <ul>\n        <li><strong>复查时机</strong>：{review_plan.get("复查时机", "-")}</li>\n'
    review_focus = review_plan.get("复查重点", [])
    if review_focus:
        html += '        <li><strong>复查重点</strong>：\n            <ul>\n'
        for f in review_focus:
            html += f"                <li>{f}</li>\n"
        html += '            </ul>\n        </li>\n'
    html += f'        <li><strong>复查方式</strong>：{review_plan.get("复查方式", "-")}</li>\n    </ul>\n'
    
    # 关键成功指标
    html += """
    <div class="level1">关键成功指标</div>
"""
    html += f'    <p>{kpi.get("前言", "建议产品团队和测试团队共同关注以下关键指标，验证本次PRD质量和产品实现效果：")}</p>\n    <ul>\n'
    for item in kpi.get("指标列表", []):
        html += f"        <li>{item}</li>\n"
    html += "    </ul>\n"
    
    # 报告尾部信息
    html += f"""
    <div class="footer">
        <p>评估报告生成时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
        <p>评估报告版本：{footer_info.get('评估报告版本', 'V1.0')}</p>
        <p>评估有效期：{footer_info.get('评估有效期', '自评估之日起3个月内有效，如PRD有重大修订需重新评估')}</p>
    </div>
</div>
</body>
</html>"""
    
    return html


def _generate_pdf_report(score: float, passed: bool, result: Dict[str, Any]) -> str:
    """生成PDF报告并上传"""
    html_content = _generate_html_report(result)
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"PRD_Evaluation_Report_{timestamp}.pdf"
    html_path = os.path.join(tempfile.gettempdir(), f"prd_report_{timestamp}.html")
    pdf_path = os.path.join(tempfile.gettempdir(), filename)
    
    with open(html_path, 'w', encoding='utf-8') as f:
        f.write(html_content)
    
    # 强制使用weasyprint生成PDF，不允许降级为HTML
    from weasyprint import HTML
    HTML(filename=html_path).write_pdf(pdf_path)
    
    storage = S3SyncStorage(
        endpoint_url=os.getenv("COZE_BUCKET_ENDPOINT_URL"),
        access_key="",
        secret_key="",
        bucket_name=os.getenv("COZE_BUCKET_NAME"),
        region="cn-beijing",
    )
    
    with open(pdf_path, 'rb') as f:
        file_content = f.read()
    
    object_key = storage.upload_file(
        file_content=file_content,
        file_name=filename,
        content_type="application/pdf",
    )
    
    return storage.generate_presigned_url(key=object_key, expire_time=3600)


def prd_evaluation_node(
    state: PrdEvaluationInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> PrdEvaluationOutput:
    """
    title: PRD测试准入质量评估
    desc: 根据PRD测试准入评估标准对PRD文档进行全维度质量评估，严格按照模板格式输出
    integrations: prd-test-quality-assessment, storage
    """
    ctx = runtime.context
    
    # 处理输入：支持文件上传和文本内容两种方式
    prd_content = ""
    if state.prd_document:
        # 文件上传方式（独立测试时）
        from utils.file.file import FileOps
        prd_content = FileOps.extract_text(state.prd_document)
    elif state.prd_content:
        # 文本内容方式（工作流连接时）
        prd_content = state.prd_content
    else:
        raise ValueError("请提供PRD文件或PRD内容")
    
    user_prompt = f"""请对以下PRD文档进行测试准入质量评估，严格按照JSON格式输出评估结果：

{prd_content}

评估要求：
1. 提取PRD基本信息
2. 判断各维度是否涉及，**特别注意非功能需求维度的判断规则**：
   - **性能指标**：只有文档明确提到具体性能指标参数（响应时间≤X秒、并发量X、吞吐量X等）才触发评估，否则给满分7分，标记"不涉及（文档未提明确性能指标），给满分"
   - **兼容性**：只有文档明确提到兼容性要求（操作系统、浏览器、设备适配等）才触发评估，否则给满分6分，标记"不涉及（文档未提兼容性要求），给满分"
   - **易用性可靠性**：只有文档明确提到易用性可靠性要求（操作流程、错误提示、可用性指标、故障恢复等）才触发评估，否则给满分7分，标记"不涉及（文档未提易用性可靠性要求），给满分"
   - **接口信息**：只有文档明确提到接口定义（接口、API、请求参数、返回参数、返回码等）才触发评估，否则给满分5分，标记"不涉及（文档未提接口定义），给满分"
3. 检查核心否决项（特别注意触发条件）：
   - **业务规则缺失**：统计业务规则不明确的数量，达6处及以上才触发检查
   - **性能无量化**：统计性能相关关键词（响应时间、延迟、并发量、吞吐量、TPS、QPS、处理时间、秒、毫秒等）数量，达10处及以上才触发检查
   - **接口核心缺失**：统计接口相关关键词（接口、API、请求参数、返回参数、返回码、请求头、响应头等）数量，达10处及以上才触发检查
   - **导入导出规则缺失**：该项不进行检查，统一标记为"不适用"
   - 其他否决项正常检查
4. 对涉及维度进行详细评估
5. 汇总问题清单，标注严重程度（阻塞性/严重/一般）
6. 按优先级P0/P1/P2生成分级改进建议
7. 计算总分并判断准入结果

**重要提示**：
- 在"维度判断与豁免说明"的"非功能需求维度"中，必须增加"各子维度判断"字段，详细说明每个子维度的触发判断
- 未触发的子维度给满分并计入总分

请严格按照JSON模板结构输出，确保所有字段完整。"""
    
    client = LLMClient(ctx=ctx)
    
    messages = [
        SystemMessage(content=PRD_EVALUATION_SP),
        HumanMessage(content=user_prompt)
    ]
    
    response = client.invoke(
        messages=messages,
        model="doubao-seed-2-0-pro-260215",
        temperature=0.3,
        max_completion_tokens=32768
    )
    
    response_content = response.content
    if isinstance(response_content, list):
        text_parts = []
        for item in response_content:
            if isinstance(item, dict) and item.get("type") == "text":
                text_parts.append(item.get("text", ""))
            elif isinstance(item, str):
                text_parts.append(item)
        response_content = "\n".join(text_parts)
    
    result = _extract_json_from_response(str(response_content))
    
    # 获取分数 - 统一分数计算逻辑
    # 优先级：1. 从"各维度得分"中找"总分"行  2. 累加各维度得分
    score_overview = result.get("评估结果总览", {})
    scores = score_overview.get("各维度得分", [])
    
    # 先尝试从"总分"行获取
    total_score = 0
    dimension_scores_sum = 0
    has_total_row = False
    
    for s in scores:
        dim_name = s.get("维度", "")
        dim_score = s.get("得分", 0)
        
        if dim_name == "总分":
            total_score = dim_score
            has_total_row = True
        else:
            dimension_scores_sum += dim_score
    
    # 如果没有"总分"行，使用累加值
    if not has_total_row:
        total_score = dimension_scores_sum
    
    score = float(total_score)
    
    # 检查核心否决项 - 如果触发了核心否决项，分数上限为59分
    veto_checks = result.get("核心否决项检查", {}).get("检查结果", [])
    has_veto_triggered = False
    for item in veto_checks:
        check_result = item.get("检查结果", "")
        if check_result == "触发":
            has_veto_triggered = True
            break
    
    if has_veto_triggered:
        # 触发核心否决项，分数上限为59分
        score = min(score, 59.0)
        # 更新准入判断
        score_overview["准入判断"] = "驳回（触发核心否决项）"
        result["评估结果总览"]["准入判断"] = "驳回（触发核心否决项）"
    
    score = max(0.0, min(100.0, score))
    passed = score >= 80
    
    # 同步更新报告中的分数，确保一致性
    # 更新"各维度得分"中的"总分"行
    total_updated = False
    for s in scores:
        if s.get("维度") == "总分":
            s["得分"] = int(score)
            s["得分率"] = f"{int(score)}%"
            total_updated = True
            break
    
    # 如果没有"总分"行，添加一个
    if not total_updated:
        scores.append({
            "维度": "总分",
            "满分": 100,
            "得分": int(score),
            "得分率": f"{int(score)}%",
            "豁免状态": "-"
        })
    
    # 生成PDF
    try:
        pdf_url = _generate_pdf_report(score, passed, result)
    except Exception as e:
        pdf_url = ""
    
    # Markdown摘要
    markdown_report = f"""# PRD质量评估报告

## 评估概要
- **PRD名称**: {result.get('评估概要', {}).get('PRD名称', '-')}
- **PRD版本**: {result.get('评估概要', {}).get('PRD版本', '-')}
- **评估日期**: {datetime.now().strftime('%Y-%m-%d')}
- **需求范围**: {result.get('评估概要', {}).get('需求范围', '-')}

## 评估结果总览
- **总分**: {score}分
- **准入判断**: {score_overview.get('准入判断', '-')}

## 测试准入判断
{result.get('测试准入判断', {}).get('准入结论', '-')}

---
*评估报告生成时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}*"""
    
    return PrdEvaluationOutput(
        prd_evaluation_score=score,
        prd_evaluation_report=markdown_report,
        prd_evaluation_passed=passed,
        prd_evaluation_report_url=pdf_url
    )
