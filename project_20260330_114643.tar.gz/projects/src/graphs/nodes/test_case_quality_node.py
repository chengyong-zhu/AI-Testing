"""
测试用例质量评估节点 - 使用test-case-evaluator技能进行质量评估
严格按照测试用例质量评估报告模板.json格式输出
"""
import os
import json
import re
import tempfile
import logging
from datetime import datetime
from typing import Dict, Any, List, Optional
from jinja2 import Template
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from coze_coding_dev_sdk import LLMClient
from coze_coding_dev_sdk.s3 import S3SyncStorage
from langchain_core.messages import SystemMessage, HumanMessage
from graphs.state import TestCaseQualityInput, TestCaseQualityOutput

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def _fix_json_string(json_str: str) -> str:
    """尝试修复常见的JSON格式问题"""
    import re
    
    # 1. 移除JSON中的注释
    json_str = re.sub(r'//.*$', '', json_str, flags=re.MULTILINE)
    json_str = re.sub(r'/\*[\s\S]*?\*/', '', json_str)
    
    # 2. 修复缺失的逗号（在 } 和 { 之间，或 ] 和 [ 之间，或 } 和 " 之间）
    # 注意：这个正则可能会引入问题，所以要谨慎使用
    # json_str = re.sub(r'(\})\s*(\{|")', r'\1,\2', json_str)
    # json_str = re.sub(r'(\])\s*(\[|{|")', r'\1,\2', json_str)
    
    # 3. 修复末尾多余的逗号
    json_str = re.sub(r',\s*}', '}', json_str)
    json_str = re.sub(r',\s*]', ']', json_str)
    
    # 4. 修复中文引号
    json_str = json_str.replace('"', '"').replace('"', '"')
    json_str = json_str.replace(''', "'").replace(''', "'")
    
    # 5. 修复换行符在字符串中未转义的问题
    # 这个比较复杂，暂时跳过
    
    return json_str


def _extract_json_from_response(content: str) -> Dict[str, Any]:
    """从LLM响应中提取JSON，增强健壮性"""
    
    # 方法1：提取```json代码块
    json_pattern = r'```json\s*([\s\S]*?)\s*```'
    matches = re.findall(json_pattern, content)
    
    for match in matches:
        try:
            result = json.loads(match)
            if isinstance(result, dict) and result:
                logger.info("成功从```json代码块中提取JSON")
                return result
        except json.JSONDecodeError as e:
            logger.warning(f"JSON代码块解析失败: {e}")
            # 尝试修复后重新解析
            try:
                fixed_json = _fix_json_string(match)
                result = json.loads(fixed_json)
                if isinstance(result, dict) and result:
                    logger.info("修复后成功解析JSON代码块")
                    return result
            except json.JSONDecodeError as e2:
                logger.warning(f"修复后仍然解析失败: {e2}")
            continue
    
    # 方法2：直接解析整个内容
    try:
        result = json.loads(content)
        if isinstance(result, dict) and result:
            logger.info("成功直接解析JSON")
            return result
    except json.JSONDecodeError:
        pass
    
    # 方法3：查找最大的JSON对象
    json_obj_pattern = r'\{[\s\S]*\}'
    match = re.search(json_obj_pattern, content)
    if match:
        try:
            result = json.loads(match.group())
            if isinstance(result, dict) and result:
                logger.info("成功从内容中提取JSON对象")
                return result
        except json.JSONDecodeError as e:
            logger.warning(f"JSON对象解析失败: {e}")
            # 尝试修复后重新解析
            try:
                fixed_json = _fix_json_string(match.group())
                result = json.loads(fixed_json)
                if isinstance(result, dict) and result:
                    logger.info("修复后成功解析JSON对象")
                    return result
            except json.JSONDecodeError as e2:
                logger.warning(f"修复后仍然解析失败: {e2}")
    
    # 方法4：尝试修复常见的JSON格式问题
    try:
        # 移除可能的前后文字
        start_idx = content.find('{')
        end_idx = content.rfind('}')
        if start_idx != -1 and end_idx != -1 and end_idx > start_idx:
            json_str = content[start_idx:end_idx + 1]
            # 先尝试直接解析
            try:
                result = json.loads(json_str)
                if isinstance(result, dict) and result:
                    logger.info("成功修复并解析JSON")
                    return result
            except json.JSONDecodeError:
                # 再尝试修复后解析
                fixed_json = _fix_json_string(json_str)
                result = json.loads(fixed_json)
                if isinstance(result, dict) and result:
                    logger.info("修复后成功解析JSON")
                    return result
    except json.JSONDecodeError as e:
        logger.warning(f"所有修复尝试都失败: {e}")
    
    # 方法5：尝试使用更宽松的方式提取关键字段
    try:
        result = _extract_partial_json(content)
        if result:
            logger.info("成功提取部分JSON字段")
            return result
    except Exception as e:
        logger.warning(f"部分提取失败: {e}")
    
    logger.error("无法从响应中提取有效JSON")
    return {}


def _extract_partial_json(content: str) -> Dict[str, Any]:
    """尝试从内容中提取关键JSON字段，即使整体JSON格式有问题"""
    result = {}
    
    # 提取业务模块
    business_match = re.search(r'"业务模块"\s*:\s*"([^"]*)"', content)
    if business_match:
        result["业务模块"] = business_match.group(1)
    
    # 提取综合得分
    score_match = re.search(r'"综合得分"\s*:\s*"([^"]*)"', content)
    if score_match:
        if "总体评价" not in result:
            result["总体评价"] = {}
        result["总体评价"]["综合得分"] = score_match.group(1)
    
    # 提取评级
    rating_match = re.search(r'"评级"\s*:\s*"([^"]*)"', content)
    if rating_match:
        if "总体评价" not in result:
            result["总体评价"] = {}
        result["总体评价"]["评级"] = rating_match.group(1)
    
    # 提取评估日期
    date_match = re.search(r'"评估日期"\s*:\s*"([^"]*)"', content)
    if date_match:
        if "总体评价" not in result:
            result["总体评价"] = {}
        result["总体评价"]["评估日期"] = date_match.group(1)
    
    # 提取各维度得分
    dimension_pattern = r'"(用例完整性|用例有效性|用例规范性|用例针对性|用例可执行性|用例可维护性|用例数据适配性)"[^}]*"得分"\s*:\s*(\d+)'
    for match in re.finditer(dimension_pattern, content):
        dim_name = match.group(1)
        dim_score = int(match.group(2))
        if "各维度详细评估" not in result:
            result["各维度详细评估"] = {}
        if dim_name not in result["各维度详细评估"]:
            result["各维度详细评估"][dim_name] = {}
        result["各维度详细评估"][dim_name]["得分"] = dim_score
    
    return result if result else None


def _calculate_total_score(result: Dict[str, Any]) -> float:
    """从各维度计算总分"""
    dimensions = result.get("各维度详细评估", {})
    total_score = 0.0
    
    for dim_name, dim_info in dimensions.items():
        if isinstance(dim_info, dict):
            score = dim_info.get("得分", 0)
            if isinstance(score, (int, float)):
                total_score += float(score)
            elif isinstance(score, str):
                try:
                    total_score += float(score)
                except ValueError:
                    pass
    
    return total_score


def _get_rating(score: float) -> str:
    """根据分数获取评级"""
    if score >= 90:
        return "优秀"
    elif score >= 80:
        return "良好"
    elif score >= 70:
        return "合格"
    elif score >= 60:
        return "待改进"
    else:
        return "不合格"


def _generate_html_report(result: Dict[str, Any]) -> str:
    """按照模板格式生成HTML报告
    
    报告格式规范：
    1. 标题只包含"测试用例质量评估报告"
    2. 全文字体颜色采用黑色
    3. 维度采用二级标题（如"1.用例完整性"），一级和二级标题均加粗
    4. 总体评价表头：综合得分|评级|评估日期
    5. 表格表头颜色：浅蓝灰#f0f2f5，数据行背景色：#ffffff（白色）
    """
    
    business_module = result.get("业务模块", "测试用例")
    overall = result.get("总体评价", {})
    dimensions = result.get("各维度详细评估", {})
    problems = result.get("问题清单", {})
    optimization = result.get("优化优先级建议", {})
    examples = result.get("优化示例", [])
    summary = result.get("总结", {})
    appendix = result.get("附录", {})
    
    # 计算总分（从各维度累加）
    total_score = _calculate_total_score(result)
    
    # 尝试从总体评价获取分数
    score_str = overall.get("综合得分", "")
    if isinstance(score_str, str) and "/" in score_str:
        try:
            score_val = float(score_str.split("/")[0].strip())
        except ValueError:
            score_val = total_score
    elif isinstance(score_str, (int, float)):
        score_val = float(score_str)
    else:
        score_val = total_score
    
    # 确保分数在合理范围
    score_val = max(0.0, min(100.0, score_val))
    
    # 确定评级
    rating = overall.get("评级", _get_rating(score_val))
    
    # 当前日期
    current_date = datetime.now().strftime('%Y-%m-%d')
    current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    
    html = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>测试用例质量评估报告</title>
    <style>
        @page {{ size: A4; margin: 1.5cm; }}
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{ font-family: "Microsoft YaHei", "SimSun", Arial, sans-serif; font-size: 10pt; line-height: 1.6; color: #000000; }}
        .page {{ width: 210mm; padding: 15mm; background: white; }}
        .header {{ text-align: center; border-bottom: 2px solid #333; padding-bottom: 10px; margin-bottom: 15px; }}
        .header h1 {{ color: #000000; font-size: 18pt; font-weight: bold; margin-bottom: 5px; }}
        table {{ width: 100%; border-collapse: collapse; margin: 8px 0; font-size: 9pt; }}
        th {{ background: #f0f2f5; color: #000000; padding: 6px 8px; text-align: center; font-weight: bold; border: 1px solid #ddd; }}
        td {{ padding: 5px 8px; border: 1px solid #ddd; vertical-align: top; background: #ffffff; }}
        tr {{ background: #ffffff; }}
        .level1 {{ color: #000000; font-size: 12pt; font-weight: bold; margin: 12px 0 8px 0; }}
        .level2 {{ color: #000000; font-size: 10pt; font-weight: bold; margin: 8px 0 5px 0; }}
        .level3 {{ font-weight: bold; margin: 5px 0; color: #000000; }}
        ul, ol {{ margin: 5px 0 5px 25px; }}
        li {{ margin: 3px 0; color: #000000; }}
        .score-box {{ text-align: center; background: #f8f9fa; border: 1px solid #dee2e6; border-radius: 8px; padding: 15px; margin: 10px 0; }}
        .score {{ font-size: 36pt; font-weight: bold; color: #000000; }}
        .rating {{ font-size: 14pt; color: #000000; background: #f0f2f5; padding: 5px 15px; border-radius: 5px; display: inline-block; margin-top: 5px; font-weight: bold; }}
        .severe {{ color: #000000; font-weight: bold; }}
        .medium {{ color: #000000; font-weight: bold; }}
        .minor {{ color: #000000; }}
        .example-box {{ background: #f8f9fa; border: 1px solid #dee2e6; border-radius: 5px; padding: 10px; margin: 8px 0; }}
        .example-title {{ font-weight: bold; color: #000000; margin-bottom: 5px; }}
        .before {{ color: #000000; }}
        .after {{ color: #000000; }}
        .footer {{ text-align: left; color: #000000; font-size: 9pt; font-weight: bold; margin-top: 15px; padding-top: 10px; border-top: 1px solid #ddd; }}
    </style>
</head>
<body>
<div class="page">
    <div class="header">
        <h1>测试用例质量评估报告</h1>
    </div>
"""
    
    # 一、总体评价
    html += """
    <div class="level1">一、总体评价</div>
    <table>
        <tr><th>综合得分</th><th>评级</th><th>评估日期</th></tr>
"""
    html += f"        <tr><td style=\"text-align: center; font-weight: bold;\">{score_val:.1f}/100</td><td style=\"text-align: center; font-weight: bold;\">{rating}</td><td style=\"text-align: center;\">{overall.get('评估日期', current_date)}</td></tr>\n"
    html += "    </table>\n"
    html += f"    <p style=\"margin: 8px 0;\">{overall.get('总体评价描述', '暂无总体评价描述')}</p>\n"
    
    # 二、各维度详细评估
    html += """
    <div class="level1">二、各维度详细评估</div>
"""
    
    dim_idx = 0
    for dim_name, dim_info in dimensions.items():
        if not isinstance(dim_info, dict):
            continue
        dim_idx += 1
        dim_score = dim_info.get("得分", 0)
        dim_full = dim_info.get("满分", 10)
        html += f"""
    <div class="level2">{dim_idx}.{dim_name}（{dim_score}/{dim_full}分）</div>
    <p><strong>评估说明：</strong>{dim_info.get('评估说明', '暂无评估说明')}</p>
"""
        # 优点
        pros = dim_info.get("优点", [])
        if pros:
            html += "    <p><strong>优点：</strong></p>\n    <ul>\n"
            for pro in pros:
                html += f"        <li>{pro}</li>\n"
            html += "    </ul>\n"
        
        # 不足
        cons = dim_info.get("不足", [])
        if cons:
            html += "    <p><strong>不足：</strong></p>\n    <ul>\n"
            for con in cons:
                html += f"        <li>{con}</li>\n"
            html += "    </ul>\n"
        
        # 改进建议
        suggestions = dim_info.get("改进建议", [])
        if suggestions:
            html += "    <p><strong>改进建议：</strong></p>\n    <ol>\n"
            for sug in suggestions:
                html += f"        <li>{sug}</li>\n"
            html += "    </ol>\n"
    
    # 三、问题清单
    html += """
    <div class="level1">三、问题清单</div>
"""
    
    problem_idx = 0
    # 严重问题
    severe_problems = problems.get("严重问题", [])
    if severe_problems:
        problem_idx += 1
        html += f"""
    <div class="level2">{problem_idx}.严重问题（建议优先修复）</div>
    <table>
        <tr><th style="width:10%">序号</th><th style="width:55%">问题</th><th style="width:20%">影响维度</th><th style="width:15%">建议优先级</th></tr>
"""
        for p in severe_problems:
            html += f"        <tr><td class=\"severe\">{p.get('序号', '-')}</td><td class=\"severe\">{p.get('问题', '-')}</td><td>{p.get('影响维度', '-')}</td><td class=\"severe\">{p.get('建议优先级', 'P1')}</td></tr>\n"
        html += "    </table>\n"
    
    # 中等问题
    medium_problems = problems.get("中等问题", [])
    if medium_problems:
        problem_idx += 1
        html += f"""
    <div class="level2">{problem_idx}.中等问题</div>
    <table>
        <tr><th style="width:10%">序号</th><th style="width:55%">问题</th><th style="width:20%">影响维度</th><th style="width:15%">建议优先级</th></tr>
"""
        for p in medium_problems:
            html += f"        <tr><td class=\"medium\">{p.get('序号', '-')}</td><td class=\"medium\">{p.get('问题', '-')}</td><td>{p.get('影响维度', '-')}</td><td class=\"medium\">{p.get('建议优先级', 'P2')}</td></tr>\n"
        html += "    </table>\n"
    
    # 轻微问题
    minor_problems = problems.get("轻微问题", [])
    if minor_problems:
        problem_idx += 1
        html += f"""
    <div class="level2">{problem_idx}.轻微问题</div>
    <table>
        <tr><th style="width:10%">序号</th><th style="width:55%">问题</th><th style="width:20%">影响维度</th><th style="width:15%">建议优先级</th></tr>
"""
        for p in minor_problems:
            html += f"        <tr><td class=\"minor\">{p.get('序号', '-')}</td><td class=\"minor\">{p.get('问题', '-')}</td><td>{p.get('影响维度', '-')}</td><td class=\"minor\">{p.get('建议优先级', 'P3')}</td></tr>\n"
        html += "    </table>\n"
    
    # 四、优化优先级建议
    html += """
    <div class="level1">四、优化优先级建议</div>
"""
    
    phase_idx = 0
    phase_order = ["第一阶段", "第二阶段", "第三阶段", "第四阶段"]
    for phase_name in phase_order:
        phase_info = optimization.get(phase_name, {})
        if phase_info:
            phase_idx += 1
            html += f"""
    <div class="level2">{phase_idx}.{phase_name}（{phase_info.get('执行周期', '-')}）</div>
    <p><strong>阶段目标：</strong>{phase_info.get('阶段目标', '-')}</p>
"""
            measures = phase_info.get("优化措施", [])
            if measures:
                html += "    <ol>\n"
                for m in measures:
                    html += f"        <li>{m}</li>\n"
                html += "    </ol>\n"
    
    # 五、优化示例
    if examples:
        html += """
    <div class="level1">五、优化示例</div>
"""
        for idx, ex in enumerate(examples, 1):
            html += f"""
    <div class="level2">{idx}.{ex.get('示例标题', f'示例{idx}')}</div>
    <div class="example-box">
        <p class="before"><strong>优化前：</strong></p>
        <ul>
"""
            for before in ex.get("优化前", []):
                html += f"            <li>{before}</li>\n"
            html += """        </ul>
        <p class="after"><strong>优化后：</strong></p>
        <ul>
"""
            for after in ex.get("优化后", []):
                html += f"            <li>{after}</li>\n"
            html += "        </ul>\n    </div>\n"
    
    # 六、总结
    html += """
    <div class="level1">六、总结</div>
"""
    
    summary_idx = 0
    # 核心优势
    advantages = summary.get("核心优势", [])
    if advantages:
        summary_idx += 1
        html += f"""
    <div class="level2">{summary_idx}.核心优势</div>
    <ol>
"""
        for adv in advantages:
            html += f"        <li>{adv}</li>\n"
        html += "    </ol>\n"
    
    # 核心短板
    shortcomings = summary.get("核心短板", [])
    if shortcomings:
        summary_idx += 1
        html += f"""
    <div class="level2">{summary_idx}.核心短板</div>
    <ol>
"""
        for short in shortcomings:
            html += f"        <li>{short}</li>\n"
        html += "    </ol>\n"
    
    # 优化价值
    optimization_value = summary.get('优化价值', '暂无优化价值说明')
    if optimization_value:
        summary_idx += 1
        html += f"""
    <div class="level2">{summary_idx}.优化价值</div>
    <p>{optimization_value}</p>
"""
    
    # 附录
    stats = appendix.get("用例统计汇总", [])
    if stats:
        html += """
    <div class="level1">附录</div>
    <div class="level2">A.用例统计汇总</div>
    <table>
        <tr><th>统计项</th><th>数值</th><th>占比</th></tr>
"""
        for stat in stats:
            html += f"        <tr><td>{stat.get('统计项', '-')}</td><td>{stat.get('数值', 0)}</td><td>{stat.get('占比', '0%')}</td></tr>\n"
        html += "    </table>\n"
    
    # 报告尾部信息
    html += f"""
    <div class="footer">
        <p>报告生成时间：{current_time}</p>
        <p>评估工具：测试用例质量评估系统 V1.0</p>
        <p>评估有效期：自评估之日起3个月内有效，如测试用例有重大修订需重新评估</p>
    </div>
</div>
</body>
</html>
"""
    
    return html


def _generate_pdf_report(result: Dict[str, Any]) -> str:
    """生成PDF报告并上传，返回URL"""
    
    # 生成HTML
    html_content = _generate_html_report(result)
    
    # 生成PDF
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"TestCase_Quality_Report_{timestamp}.pdf"
    html_path = os.path.join(tempfile.gettempdir(), f"quality_report_{timestamp}.html")
    pdf_path = os.path.join(tempfile.gettempdir(), filename)
    
    # 保存HTML
    with open(html_path, 'w', encoding='utf-8') as f:
        f.write(html_content)
    
    # 强制使用weasyprint生成PDF，不允许降级为HTML
    from weasyprint import HTML
    HTML(filename=html_path).write_pdf(pdf_path)
    
    # 上传到对象存储
    storage = S3SyncStorage(
        endpoint_url=os.getenv("COZE_BUCKET_ENDPOINT_URL"),
        access_key="",
        secret_key="",
        bucket_name=os.getenv("COZE_BUCKET_NAME"),
        region="cn-beijing",
    )
    
    with open(pdf_path, 'rb') as f:
        file_content = f.read()
    
    object_key = storage.upload_file(
        file_content=file_content,
        file_name=filename,
        content_type="application/pdf",
    )
    
    # 生成预签名URL
    signed_url = storage.generate_presigned_url(key=object_key, expire_time=3600)
    return signed_url


def test_case_quality_node(
    state: TestCaseQualityInput,
    config: RunnableConfig,
    runtime: Runtime[Context]
) -> TestCaseQualityOutput:
    """
    title: 测试用例质量评估
    desc: 根据测试用例量化评估标准对测试用例进行七维度质量评估，按照模板格式生成PDF报告
    integrations: test-case-evaluator, storage
    """
    ctx = runtime.context
    
    # 处理输入：支持文件上传和数据传递两种方式
    from utils.file.file import FileOps
    
    # 处理测试用例输入
    test_cases = []
    if state.test_case_file:
        # 文件上传方式（独立测试时）
        # 读取Excel或XMind文件
        file_content = FileOps.extract_text(state.test_case_file)
        # 尝试解析JSON（如果是JSON格式）
        try:
            test_cases = json.loads(file_content)
        except:
            # 如果不是JSON，可能需要其他处理方式
            # 这里暂时将整个内容作为一个测试用例
            test_cases = [{"内容": file_content}]
    elif state.test_cases:
        # 数据传递方式（工作流连接时）
        test_cases = state.test_cases
    else:
        raise ValueError("请提供测试用例文件或测试用例数据")
    
    # 处理PRD输入
    prd_content = ""
    if state.prd_file:
        # 文件上传方式（独立测试时）
        prd_content = FileOps.extract_text(state.prd_file)
    elif state.prd_content:
        # 文本内容方式（工作流连接时）
        prd_content = state.prd_content
    else:
        logger.warning("未提供PRD文件或内容，将仅基于测试用例进行评估")
    
    # 读取配置文件
    cfg_path = os.path.join(os.getenv("COZE_WORKSPACE_PATH", ""), "config", "test_case_quality_llm_cfg.json")
    try:
        with open(cfg_path, 'r', encoding='utf-8') as f:
            cfg = json.load(f)
        llm_config = cfg.get("config", {})
        sp = cfg.get("sp", "")
        up = cfg.get("up", "")
    except Exception as e:
        logger.error(f"读取配置文件失败: {e}")
        llm_config = {
            "model": "doubao-seed-2-0-pro-260215",
            "temperature": 0.3,
            "max_completion_tokens": 32768
        }
        sp = ""
        up = ""
    
    # 将测试用例转为JSON字符串
    test_cases_json = json.dumps(test_cases, ensure_ascii=False, indent=2)
    
    # 使用jinja2渲染用户提示词
    up_tpl = Template(up)
    user_prompt = up_tpl.render({
        "prd_content": prd_content,
        "test_cases_json": test_cases_json
    })
    
    # 调用大模型进行评估
    client = LLMClient(ctx=ctx)
    
    messages = [
        SystemMessage(content=sp),
        HumanMessage(content=user_prompt)
    ]
    
    response = client.invoke(
        messages=messages,
        model=llm_config.get("model", "doubao-seed-2-0-pro-260215"),
        temperature=llm_config.get("temperature", 0.3),
        max_completion_tokens=llm_config.get("max_completion_tokens", 32768)
    )
    
    # 处理响应内容
    response_content = response.content
    if isinstance(response_content, list):
        text_parts = []
        for item in response_content:
            if isinstance(item, dict) and item.get("type") == "text":
                text_parts.append(item.get("text", ""))
            elif isinstance(item, str):
                text_parts.append(item)
        response_content = "\n".join(text_parts)
    
    logger.info(f"LLM响应长度: {len(str(response_content))}")
    
    # 记录LLM原始响应的前500个字符，方便调试
    logger.info(f"LLM响应前500字符: {str(response_content)[:500]}")
    
    # 提取JSON结果
    result = _extract_json_from_response(str(response_content))
    
    if not result:
        logger.error("无法解析LLM响应，使用默认结果")
        logger.error(f"LLM完整响应内容: {str(response_content)}")
        result = {
            "业务模块": "测试用例",
            "总体评价": {
                "综合得分": "70/100",
                "评级": "合格",
                "评估日期": datetime.now().strftime('%Y-%m-%d'),
                "总体评价描述": "LLM响应解析失败，使用默认评分"
            },
            "各维度详细评估": {
                "用例完整性": {"得分": 20, "满分": 28, "评估说明": "默认评分", "优点": [], "不足": ["无法解析"], "改进建议": []},
                "用例有效性": {"得分": 15, "满分": 23, "评估说明": "默认评分", "优点": [], "不足": [], "改进建议": []},
                "用例规范性": {"得分": 15, "满分": 18, "评估说明": "默认评分", "优点": [], "不足": [], "改进建议": []},
                "用例针对性": {"得分": 10, "满分": 14, "评估说明": "默认评分", "优点": [], "不足": [], "改进建议": []},
                "用例可执行性": {"得分": 5, "满分": 7, "评估说明": "默认评分", "优点": [], "不足": [], "改进建议": []},
                "用例可维护性": {"得分": 3, "满分": 5, "评估说明": "默认评分", "优点": [], "不足": [], "改进建议": []},
                "用例数据适配性": {"得分": 2, "满分": 5, "评估说明": "默认评分", "优点": [], "不足": [], "改进建议": []}
            },
            "问题清单": {"严重问题": [], "中等问题": [], "轻微问题": []},
            "优化优先级建议": {},
            "优化示例": [],
            "总结": {"核心优势": [], "核心短板": [], "优化价值": ""},
            "附录": {"用例统计汇总": []}
        }
    
    # 计算分数（从各维度累加，确保准确性）
    total_score = _calculate_total_score(result)
    logger.info(f"计算的分数: {total_score}")
    
    # 记录各维度包含的字段，方便调试
    dimensions = result.get("各维度详细评估", {})
    for dim_name, dim_info in dimensions.items():
        if isinstance(dim_info, dict):
            fields = list(dim_info.keys())
            logger.info(f"维度 {dim_name} 包含字段: {fields}")
    
    # 确保分数在合理范围内
    total_score = max(0.0, min(100.0, total_score))
    
    # 同步更新总体评价中的分数，确保报告与输出一致
    if "总体评价" not in result:
        result["总体评价"] = {}
    
    result["总体评价"]["综合得分"] = f"{int(total_score)}/100"
    result["总体评价"]["评级"] = _get_rating(total_score)
    result["总体评价"]["评估日期"] = datetime.now().strftime('%Y-%m-%d')
    
    # 同步更新各维度详细评估中的得分
    dimensions = result.get("各维度详细评估", {})
    dimension_full_scores = {
        "用例完整性": 28,
        "用例有效性": 23,
        "用例规范性": 18,
        "用例针对性": 14,
        "用例可执行性": 7,
        "用例可维护性": 5,
        "用例数据适配性": 5
    }
    
    for dim_name, dim_info in dimensions.items():
        if isinstance(dim_info, dict):
            # 确保满分字段正确
            if dim_name in dimension_full_scores:
                dim_info["满分"] = dimension_full_scores[dim_name]
            
            # 确保所有必需字段都存在（自动补充缺失字段）
            if "评估说明" not in dim_info or not dim_info["评估说明"]:
                dim_info["评估说明"] = f"{dim_name}评估得分{dim_info.get('得分', 0)}分"
                logger.warning(f"维度 {dim_name} 缺少评估说明字段，已自动补充")
            
            if "优点" not in dim_info:
                dim_info["优点"] = []
                logger.warning(f"维度 {dim_name} 缺少优点字段，已自动补充为空数组")
            
            if "不足" not in dim_info:
                dim_info["不足"] = []
                logger.warning(f"维度 {dim_name} 缺少不足字段，已自动补充为空数组")
            
            if "改进建议" not in dim_info:
                dim_info["改进建议"] = []
                logger.warning(f"维度 {dim_name} 缺少改进建议字段，已自动补充为空数组")
    
    # 生成PDF报告
    try:
        pdf_url = _generate_pdf_report(result)
    except Exception as e:
        logger.error(f"生成PDF报告失败: {e}")
        pdf_url = ""
    
    # 从问题清单生成修改建议文本
    suggestions_parts = []
    problems = result.get("问题清单", {})
    
    severe = problems.get("严重问题", [])
    if severe:
        suggestions_parts.append("【严重问题-P1优先修复】")
        for p in severe:
            suggestions_parts.append(f"  - {p.get('问题', '-')}")
    
    medium = problems.get("中等问题", [])
    if medium:
        suggestions_parts.append("【中等问题-P2短期优化】")
        for p in medium:
            suggestions_parts.append(f"  - {p.get('问题', '-')}")
    
    minor = problems.get("轻微问题", [])
    if minor:
        suggestions_parts.append("【轻微问题-P3持续优化】")
        for p in minor:
            suggestions_parts.append(f"  - {p.get('问题', '-')}")
    
    suggestions = "\n".join(suggestions_parts) if suggestions_parts else "测试用例质量良好，暂无重大问题需要修改。"
    
    # 生成报告文本
    report_text = json.dumps(result, ensure_ascii=False, indent=2)
    
    return TestCaseQualityOutput(
        test_case_evaluation_score=total_score,
        test_case_evaluation_report=report_text,
        test_case_modification_suggestions=suggestions,
        test_case_evaluation_report_url=pdf_url
    )
