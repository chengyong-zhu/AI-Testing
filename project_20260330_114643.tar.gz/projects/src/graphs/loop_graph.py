"""
独立子图定义 - 支持三个节点单独测试

包含三个独立子图：
1. prd_evaluation_graph - PRD测试准入质量评估独立子图
   - 输入：PRD文件（支持word、markdown等格式）
   - 输出：PRD评估报告PDF下载链接
   
2. test_case_generation_graph - 测试用例生成独立子图
   - 输入：PRD文件（支持word、markdown等格式）
   - 输出：测试用例Excel下载链接
   
3. test_case_quality_graph - 测试用例质量评估独立子图
   - 输入：测试用例文件（支持excel、xmind等格式）
   - 输出：测试用例质量评估报告PDF下载链接
"""
import os
import json
import logging
import tempfile
import zipfile
import xml.etree.ElementTree as ET
from datetime import datetime
from typing import Dict, Any, List, Optional
from pydantic import BaseModel, Field
from langgraph.graph import StateGraph, END
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime
from coze_coding_utils.runtime_ctx.context import Context
from coze_coding_dev_sdk.s3 import S3SyncStorage
from utils.file.file import File, FileOps

from graphs.state import (
    # 独立子图输入输出
    PrdEvaluationGraphInput,
    PrdEvaluationGraphOutput,
    TestCaseGenerationGraphInput,
    TestCaseGenerationGraphOutput,
    TestCaseQualityGraphInput,
    TestCaseQualityGraphOutput,
)

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


# ==================== PRD评估独立子图 ====================

def _prd_evaluation_wrapper_node(
    state,
    config: RunnableConfig,
    runtime: Runtime
):
    """
    title: PRD评估包装节点
    desc: 处理文件上传、提取内容、调用评估逻辑、生成PDF报告
    integrations: 对象存储
    """
    from graphs.nodes.prd_evaluation_node import prd_evaluation_node
    from graphs.state import PrdEvaluationInput
    
    ctx = runtime.context
    
    # 1. 提取PRD文件内容
    prd_file = state.prd_file
    if prd_file is None:
        raise ValueError("PRD文件不能为空")
    
    logger.info(f"开始提取PRD文件内容: {prd_file.url if hasattr(prd_file, 'url') else prd_file}")
    prd_content = FileOps.extract_text(prd_file)
    logger.info(f"PRD文件内容提取完成，长度: {len(prd_content)}")
    
    # 2. 调用PRD评估节点
    eval_input = PrdEvaluationInput(prd_content=prd_content)
    eval_output = prd_evaluation_node(eval_input, config, runtime)
    
    # 3. 返回结果
    return {
        "prd_content": prd_content,
        "prd_evaluation_score": eval_output.prd_evaluation_score,
        "prd_evaluation_passed": eval_output.prd_evaluation_passed,
        "prd_evaluation_report": eval_output.prd_evaluation_report,
        "prd_evaluation_report_url": eval_output.prd_evaluation_report_url,
    }


def _create_prd_evaluation_graph():
    """创建PRD评估独立子图
    
    支持上传word、markdown等格式的PRD文件进行测试准入质量评估
    """
    
    class _PrdEvaluationInternalState(BaseModel):
        """PRD评估内部状态"""
        prd_file: Optional[File] = Field(default=None, description="上传的PRD文件")
        prd_content: str = Field(default="", description="PRD文档内容")
        prd_evaluation_score: float = Field(default=0.0, description="PRD评估分数")
        prd_evaluation_passed: bool = Field(default=False, description="PRD是否通过准入")
        prd_evaluation_report: str = Field(default="", description="PRD评估报告")
        prd_evaluation_report_url: str = Field(default="", description="PRD评估报告PDF URL")
    
    builder = StateGraph(
        _PrdEvaluationInternalState,
        input_schema=PrdEvaluationGraphInput,
        output_schema=PrdEvaluationGraphOutput
    )
    
    builder.add_node("prd_evaluation_wrapper", _prd_evaluation_wrapper_node)
    builder.set_entry_point("prd_evaluation_wrapper")
    builder.add_edge("prd_evaluation_wrapper", END)
    
    return builder.compile()


# ==================== 测试用例生成独立子图 ====================

def _test_case_generation_wrapper_node(
    state,
    config: RunnableConfig,
    runtime: Runtime
):
    """
    title: 测试用例生成包装节点
    desc: 处理PRD文件上传、提取内容、生成测试用例、生成Excel文件
    integrations: 对象存储
    """
    from graphs.nodes.test_case_generation_node import test_case_generation_node
    from graphs.state import TestCaseGenerationInput
    
    ctx = runtime.context
    
    # 1. 提取PRD文件内容
    prd_file = state.prd_file
    if prd_file is None:
        raise ValueError("PRD文件不能为空")
    
    logger.info(f"开始提取PRD文件内容: {prd_file.url if hasattr(prd_file, 'url') else prd_file}")
    prd_content = FileOps.extract_text(prd_file)
    logger.info(f"PRD文件内容提取完成，长度: {len(prd_content)}")
    
    # 2. 调用测试用例生成节点
    gen_input = TestCaseGenerationInput(prd_content=prd_content)
    gen_output = test_case_generation_node(gen_input, config, runtime)
    
    # 3. 返回结果
    return {
        "test_cases": gen_output.test_cases,
        "test_case_excel_url": gen_output.test_case_excel_url,
    }


def _create_test_case_generation_graph():
    """创建测试用例生成独立子图
    
    支持上传word、markdown等格式的PRD文件生成测试用例
    """
    
    class _TestCaseGenerationInternalState(BaseModel):
        """测试用例生成内部状态"""
        prd_file: Optional[File] = Field(default=None, description="上传的PRD文件")
        test_cases: List[Dict[str, Any]] = Field(default=[], description="生成的测试用例列表")
        test_case_excel_url: str = Field(default="", description="测试用例Excel URL")
    
    builder = StateGraph(
        _TestCaseGenerationInternalState,
        input_schema=TestCaseGenerationGraphInput,
        output_schema=TestCaseGenerationGraphOutput
    )
    
    builder.add_node("test_case_generation_wrapper", _test_case_generation_wrapper_node)
    builder.set_entry_point("test_case_generation_wrapper")
    builder.add_edge("test_case_generation_wrapper", END)
    
    return builder.compile()


# ==================== 测试用例质量评估独立子图 ====================

def _parse_test_cases_from_excel(excel_file: File) -> List[Dict[str, Any]]:
    """从Excel文件解析测试用例"""
    import pandas as pd
    import requests
    
    # 下载文件到临时目录
    file_url = excel_file.url
    
    with tempfile.NamedTemporaryFile(suffix='.xlsx', delete=False) as tmp:
        if file_url.startswith('http'):
            response = requests.get(file_url, timeout=60)
            tmp.write(response.content)
        else:
            # 本地文件
            with open(file_url, 'rb') as f:
                tmp.write(f.read())
        tmp_path = tmp.name
    
    try:
        # 读取Excel文件
        df = pd.read_excel(tmp_path)
        logger.info(f"Excel文件读取成功，共{len(df)}行数据")
        
        # 转换为测试用例列表
        test_cases: List[Dict[str, Any]] = []
        for idx, row in df.iterrows():
            case: Dict[str, Any] = {
                "level1Module": str(row.get("一级模块", row.get("level1Module", ""))),
                "level2Module": str(row.get("二级模块", row.get("level2Module", ""))),
                "level3Module": str(row.get("三级模块", row.get("level3Module", ""))),
                "level4Module": str(row.get("四级模块", row.get("level4Module", ""))),
                "caseName": str(row.get("用例名称", row.get("caseName", ""))),
                "priority": str(row.get("优先级", row.get("priority", ""))),
                "caseType": str(row.get("用例类型", row.get("caseType", ""))),
                "preconditions": str(row.get("前置条件", row.get("preconditions", ""))),
                "steps": str(row.get("步骤描述", row.get("steps", ""))),
                "expectedResults": str(row.get("预期结果", row.get("expectedResults", ""))),
                "remarks": str(row.get("备注", row.get("remarks", ""))),
                "caseCategory": str(row.get("用例类别", row.get("caseCategory", ""))),
                "maintainer": str(row.get("维护人", row.get("maintainer", "测试工程师"))),
                "applicableScenario": str(row.get("适用场景", row.get("applicableScenario", ""))),
            }
            test_cases.append(case)
        
        logger.info(f"解析出{len(test_cases)}条测试用例")
        return test_cases
    finally:
        # 清理临时文件
        if os.path.exists(tmp_path):
            os.unlink(tmp_path)


def _parse_test_cases_from_xmind(xmind_file: File) -> List[Dict[str, Any]]:
    """从XMind文件解析测试用例"""
    import requests
    
    file_url = xmind_file.url
    
    with tempfile.NamedTemporaryFile(suffix='.xmind', delete=False) as tmp:
        if file_url.startswith('http'):
            response = requests.get(file_url, timeout=60)
            tmp.write(response.content)
        else:
            with open(file_url, 'rb') as f:
                tmp.write(f.read())
        tmp_path = tmp.name
    
    try:
        test_cases: List[Dict[str, Any]] = []
        
        # XMind是一个ZIP文件
        with zipfile.ZipFile(tmp_path, 'r') as z:
            # 查找content.xml或content.json
            for name in z.namelist():
                if 'content' in name.lower():
                    content = z.read(name)
                    
                    # 尝试解析JSON格式（XMind 8+）
                    if name.endswith('.json'):
                        try:
                            data = json.loads(content)
                            # 解析XMind JSON格式
                            def extract_topics(topic: Dict[str, Any], path: List[str] = []) -> List[Dict[str, Any]]:
                                cases: List[Dict[str, Any]] = []
                                title = topic.get('title', '')
                                current_path = path + [title]
                                
                                children = topic.get('children', {}).get('attached', [])
                                if not children:
                                    # 叶子节点，可能是测试用例
                                    if len(current_path) >= 2:
                                        case: Dict[str, Any] = {
                                            "level1Module": current_path[0] if len(current_path) > 0 else "",
                                            "level2Module": current_path[1] if len(current_path) > 1 else "",
                                            "level3Module": current_path[2] if len(current_path) > 2 else "",
                                            "level4Module": current_path[3] if len(current_path) > 3 else "",
                                            "caseName": title,
                                            "priority": "P2",
                                            "caseType": "功能测试",
                                            "preconditions": "",
                                            "steps": "",
                                            "expectedResults": "",
                                            "remarks": "",
                                            "caseCategory": "软件功能",
                                            "maintainer": "测试工程师",
                                            "applicableScenario": "",
                                        }
                                        cases.append(case)
                                else:
                                    for child in children:
                                        cases.extend(extract_topics(child, current_path))
                                
                                return cases
                            
                            if isinstance(data, list):
                                for item in data:
                                    test_cases.extend(extract_topics(item))
                            elif isinstance(data, dict):
                                root = data.get('rootTopic', data)
                                test_cases = extract_topics(root)
                            
                            logger.info(f"从XMind JSON解析出{len(test_cases)}条测试用例")
                        except json.JSONDecodeError:
                            pass
                    
                    # 尝试解析XML格式（XMind 3.x）
                    elif name.endswith('.xml'):
                        try:
                            root = ET.fromstring(content)
                            # 简化处理，提取所有文本节点
                            for elem in root.iter():
                                if elem.text and elem.text.strip():
                                    # 这里需要根据实际XMind格式进行解析
                                    pass
                        except ET.ParseError:
                            pass
        
        return test_cases
    finally:
        if os.path.exists(tmp_path):
            os.unlink(tmp_path)


def _test_case_quality_wrapper_node(
    state,
    config: RunnableConfig,
    runtime: Runtime
):
    """
    title: 测试用例质量评估包装节点
    desc: 处理测试用例文件上传、解析内容、进行质量评估、生成PDF报告
    integrations: 对象存储
    """
    from graphs.nodes.test_case_quality_node import test_case_quality_node
    from graphs.state import TestCaseQualityInput
    
    ctx = runtime.context
    
    # 1. 解析测试用例文件
    test_case_file = state.test_case_file
    if test_case_file is None:
        raise ValueError("测试用例文件不能为空")
    
    file_url = test_case_file.url
    file_name = file_url.split('/')[-1].split('?')[0] if '?' in file_url else file_url.split('/')[-1]
    
    logger.info(f"开始解析测试用例文件: {file_name}")
    
    # 根据文件类型选择解析方法
    if file_name.endswith('.xlsx') or file_name.endswith('.xls'):
        test_cases = _parse_test_cases_from_excel(test_case_file)
    elif file_name.endswith('.xmind'):
        test_cases = _parse_test_cases_from_xmind(test_case_file)
    else:
        raise ValueError(f"不支持的文件格式: {file_name}，仅支持excel(.xlsx/.xls)和xmind格式")
    
    if not test_cases:
        raise ValueError("未能从文件中解析出测试用例")
    
    logger.info(f"解析出{len(test_cases)}条测试用例")
    
    # 2. 调用测试用例质量评估节点
    quality_input = TestCaseQualityInput(
        test_cases=test_cases,
        prd_content=""  # 独立评估时可能没有PRD内容
    )
    quality_output = test_case_quality_node(quality_input, config, runtime)
    
    # 3. 返回结果
    return {
        "test_case_evaluation_score": quality_output.test_case_evaluation_score,
        "test_case_evaluation_report": quality_output.test_case_evaluation_report,
        "test_case_evaluation_report_url": quality_output.test_case_evaluation_report_url,
        "test_case_modification_suggestions": quality_output.test_case_modification_suggestions,
    }


def _create_test_case_quality_graph():
    """创建测试用例质量评估独立子图
    
    支持上传excel、xmind等格式的测试用例文件进行质量评估
    """
    
    class _TestCaseQualityInternalState(BaseModel):
        """测试用例质量评估内部状态"""
        test_case_file: Optional[File] = Field(default=None, description="上传的测试用例文件")
        test_case_evaluation_score: float = Field(default=0.0, description="测试用例评估分数")
        test_case_evaluation_report: str = Field(default="", description="测试用例评估报告")
        test_case_evaluation_report_url: str = Field(default="", description="测试用例评估报告PDF URL")
        test_case_modification_suggestions: str = Field(default="", description="测试用例修改意见")
    
    builder = StateGraph(
        _TestCaseQualityInternalState,
        input_schema=TestCaseQualityGraphInput,
        output_schema=TestCaseQualityGraphOutput
    )
    
    builder.add_node("test_case_quality_wrapper", _test_case_quality_wrapper_node)
    builder.set_entry_point("test_case_quality_wrapper")
    builder.add_edge("test_case_quality_wrapper", END)
    
    return builder.compile()


# ==================== 导出三个独立子图 ====================

prd_evaluation_graph = _create_prd_evaluation_graph()
test_case_generation_graph = _create_test_case_generation_graph()
test_case_quality_graph = _create_test_case_quality_graph()
