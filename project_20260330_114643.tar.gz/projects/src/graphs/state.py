"""
PRD测试准入与测试用例生成工作流 - 状态定义
"""
from typing import Optional, List, Dict, Any, Literal, Union
from pydantic import BaseModel, Field
from utils.file.file import File


# ==================== 全局状态定义 ====================
class GlobalState(BaseModel):
    """工作流全局状态"""
    # PRD相关
    prd_document: File = Field(..., description="上传的PRD文档")
    prd_content: str = Field(default="", description="PRD文档内容")
    
    # PRD评估结果
    prd_evaluation_score: float = Field(default=0.0, description="PRD评估分数")
    prd_evaluation_report: str = Field(default="", description="PRD评估报告(Markdown格式)")
    prd_evaluation_report_url: str = Field(default="", description="PRD评估报告PDF文件URL")
    prd_evaluation_passed: bool = Field(default=False, description="PRD是否通过准入(≥80分)")
    
    # 测试用例相关
    test_cases: List[Dict[str, Any]] = Field(default=[], description="生成的测试用例列表")
    test_case_excel_url: str = Field(default="", description="测试用例Excel文件URL")
    
    # 测试用例评估结果
    test_case_evaluation_score: float = Field(default=0.0, description="测试用例评估分数")
    test_case_evaluation_report: str = Field(default="", description="测试用例评估报告(Markdown格式)")
    test_case_evaluation_report_url: str = Field(default="", description="测试用例评估报告PDF文件URL")
    test_case_modification_suggestions: str = Field(default="", description="测试用例修改意见")
    
    # 测试用例完善相关（仅进行1轮完善）
    refined_test_cases: List[Dict[str, Any]] = Field(default=[], description="完善后的测试用例列表")
    refined_test_case_excel_url: str = Field(default="", description="完善后的测试用例Excel文件URL")
    refined_test_case_evaluation_score: float = Field(default=0.0, description="完善后的测试用例评估分数")
    refined_test_case_evaluation_report_url: str = Field(default="", description="完善后的测试用例评估报告PDF文件URL")
    refinement_count: int = Field(default=0, description="已完善轮次(限制为1轮)")


# ==================== 工作流入参定义 ====================
class GraphInput(BaseModel):
    """工作流输入参数"""
    prd_document: File = Field(..., description="上传的PRD文档")


# ==================== 工作流出参定义 ====================
class GraphOutput(BaseModel):
    """工作流输出参数"""
    # PRD评估结果
    prd_evaluation_score: float = Field(default=0.0, description="PRD评估分数")
    prd_evaluation_report: str = Field(default="", description="PRD评估报告")
    prd_evaluation_report_url: str = Field(default="", description="PRD评估报告PDF下载链接")
    prd_evaluation_passed: bool = Field(default=False, description="PRD是否通过准入")
    
    # 测试用例结果（仅当PRD通过时）
    test_case_excel_url: str = Field(default="", description="测试用例Excel下载链接")
    test_cases: List[Dict[str, Any]] = Field(default=[], description="测试用例列表")
    
    # 测试用例评估结果
    test_case_evaluation_score: float = Field(default=0.0, description="测试用例评估分数")
    test_case_evaluation_report: str = Field(default="", description="测试用例评估报告")
    test_case_evaluation_report_url: str = Field(default="", description="测试用例评估报告PDF下载链接")
    test_case_modification_suggestions: str = Field(default="", description="测试用例修改意见")
    
    # 测试用例完善结果（仅当原始评估分数<90分时）
    refined_test_case_excel_url: str = Field(default="", description="完善后的测试用例Excel下载链接")
    refined_test_cases: List[Dict[str, Any]] = Field(default=[], description="完善后的测试用例列表")
    refined_test_case_evaluation_score: float = Field(default=0.0, description="完善后的测试用例评估分数")
    refined_test_case_evaluation_report_url: str = Field(default="", description="完善后的测试用例评估报告PDF下载链接")
    refinement_count: int = Field(default=0, description="已完善轮次")


# ==================== 节点入参定义 ====================

# PRD内容提取节点
class PrdContentExtractionInput(BaseModel):
    """PRD内容提取节点输入"""
    prd_document: File = Field(..., description="PRD文档")


class PrdContentExtractionOutput(BaseModel):
    """PRD内容提取节点输出"""
    prd_content: str = Field(..., description="PRD文档内容")


# PRD评估节点
class PrdEvaluationInput(BaseModel):
    """PRD评估节点输入
    
    支持两种输入方式：
    1. 文件上传（独立测试时）：上传word、markdown等格式的PRD文件
    2. 文本内容（工作流连接时）：从上游节点传递的PRD文本内容
    """
    prd_document: Optional[File] = Field(None, description="PRD文件(支持word、markdown等格式，独立测试时上传)")
    prd_content: str = Field(default="", description="PRD文档内容(工作流连接时从上游传递)")


class PrdEvaluationOutput(BaseModel):
    """PRD评估节点输出"""
    prd_evaluation_score: float = Field(..., description="PRD评估分数(0-100)")
    prd_evaluation_report: str = Field(..., description="PRD评估报告(Markdown格式)")
    prd_evaluation_passed: bool = Field(..., description="PRD是否通过准入(≥80分)")
    prd_evaluation_report_url: str = Field(default="", description="PRD评估报告PDF下载链接")


# 条件分支判断节点
class CheckPrdScoreInput(BaseModel):
    """PRD分数判断节点输入"""
    prd_evaluation_score: float = Field(..., description="PRD评估分数")
    prd_evaluation_passed: bool = Field(..., description="PRD是否通过准入")


class CheckPrdScoreOutput(BaseModel):
    """PRD分数判断节点输出"""
    branch_result: str = Field(..., description="分支结果: '进入测试用例生成' 或 'PRD未通过准入'")


# 测试用例生成节点
class TestCaseGenerationInput(BaseModel):
    """测试用例生成节点输入
    
    支持两种输入方式：
    1. 文件上传（独立测试时）：上传word、markdown等格式的PRD文件
    2. 文本内容（工作流连接时）：从上游节点传递的PRD文本内容
    """
    prd_document: Optional[File] = Field(None, description="PRD文件(支持word、markdown等格式，独立测试时上传)")
    prd_content: str = Field(default="", description="PRD文档内容(工作流连接时从上游传递)")


class TestCaseGenerationOutput(BaseModel):
    """测试用例生成节点输出"""
    test_cases: List[Dict[str, Any]] = Field(..., description="生成的测试用例列表")
    test_case_excel_url: str = Field(default="", description="测试用例Excel下载链接")


# Excel生成节点
class ExcelGenerationInput(BaseModel):
    """Excel生成节点输入"""
    test_cases: List[Dict[str, Any]] = Field(..., description="测试用例列表")


class ExcelGenerationOutput(BaseModel):
    """Excel生成节点输出"""
    test_case_excel_url: str = Field(..., description="Excel文件URL")


# 测试用例质量评估节点
class TestCaseQualityInput(BaseModel):
    """测试用例质量评估节点输入
    
    支持两种输入方式：
    1. 文件上传（独立测试时）：上传Excel、XMind等格式的测试用例文件，以及PRD文件
    2. 数据传递（工作流连接时）：从上游节点传递的测试用例列表和PRD文本内容
    """
    test_case_file: Optional[File] = Field(None, description="测试用例文件(支持Excel、XMind格式，独立测试时上传)")
    test_cases: List[Dict[str, Any]] = Field(default=[], description="测试用例列表(工作流连接时从上游传递)")
    prd_file: Optional[File] = Field(None, description="PRD文件(独立测试时上传)")
    prd_content: str = Field(default="", description="PRD文档内容(工作流连接时从上游传递，用于对照评估)")


class TestCaseQualityOutput(BaseModel):
    """测试用例质量评估节点输出"""
    test_case_evaluation_score: float = Field(..., description="测试用例评估分数(0-100)")
    test_case_evaluation_report: str = Field(..., description="测试用例评估报告(Markdown格式)")
    test_case_modification_suggestions: str = Field(default="", description="测试用例修改意见")
    test_case_evaluation_report_url: str = Field(default="", description="测试用例评估报告PDF下载链接")


# 最终结果输出节点
class ResultOutputInput(BaseModel):
    """最终结果输出节点输入"""
    prd_evaluation_score: float = Field(..., description="PRD评估分数")
    prd_evaluation_report: str = Field(..., description="PRD评估报告")
    prd_evaluation_passed: bool = Field(..., description="PRD是否通过准入")
    prd_evaluation_report_url: str = Field(default="", description="PRD评估报告PDF URL")
    test_case_excel_url: str = Field(default="", description="测试用例Excel URL")
    test_cases: List[Dict[str, Any]] = Field(default=[], description="测试用例列表")
    test_case_evaluation_score: float = Field(default=0.0, description="测试用例评估分数")
    test_case_evaluation_report: str = Field(default="", description="测试用例评估报告")
    test_case_evaluation_report_url: str = Field(default="", description="测试用例评估报告PDF URL")
    test_case_modification_suggestions: str = Field(default="", description="修改意见")
    # 完善后的测试用例相关
    refined_test_case_excel_url: str = Field(default="", description="完善后的测试用例Excel URL")
    refined_test_cases: List[Dict[str, Any]] = Field(default=[], description="完善后的测试用例列表")
    refined_test_case_evaluation_score: float = Field(default=0.0, description="完善后的测试用例评估分数")
    refined_test_case_evaluation_report_url: str = Field(default="", description="完善后的测试用例评估报告PDF URL")
    refinement_count: int = Field(default=0, description="已完善轮次")


class ResultOutputOutput(BaseModel):
    """最终结果输出节点输出"""
    final_report: str = Field(..., description="最终报告(Markdown格式)")


# PRD评估报告PDF生成节点
class PrdReportPdfInput(BaseModel):
    """PRD评估报告PDF生成节点输入"""
    prd_evaluation_score: float = Field(..., description="PRD评估分数")
    prd_evaluation_report: str = Field(..., description="PRD评估报告(Markdown)")
    prd_evaluation_passed: bool = Field(..., description="PRD是否通过准入")


class PrdReportPdfOutput(BaseModel):
    """PRD评估报告PDF生成节点输出"""
    prd_evaluation_report_url: str = Field(..., description="PRD评估报告PDF文件URL")


# 测试用例质量报告PDF生成节点
class TestCaseReportPdfInput(BaseModel):
    """测试用例质量报告PDF生成节点输入"""
    test_case_evaluation_score: float = Field(..., description="测试用例评估分数")
    test_case_evaluation_report: str = Field(..., description="测试用例评估报告(Markdown)")
    test_case_modification_suggestions: str = Field(default="", description="修改意见")


class TestCaseReportPdfOutput(BaseModel):
    """测试用例质量报告PDF生成节点输出"""
    test_case_evaluation_report_url: str = Field(..., description="测试用例评估报告PDF文件URL")


# ==================== 独立子图入参出参定义 ====================

# ==================== PRD评估独立子图 ====================
class PrdEvaluationGraphInput(BaseModel):
    """PRD评估独立子图输入参数
    
    支持上传word、markdown等格式的PRD文件
    """
    prd_file: File = Field(..., description="上传的PRD文件(支持word、markdown等格式)")


class PrdEvaluationGraphOutput(BaseModel):
    """PRD评估独立子图输出参数
    
    输出PRD测试准入质量评估报告PDF下载链接
    """
    prd_evaluation_score: float = Field(default=0.0, description="PRD评估分数(0-100)")
    prd_evaluation_passed: bool = Field(default=False, description="PRD是否通过准入(≥80分)")
    prd_evaluation_report: str = Field(default="", description="PRD评估报告(Markdown格式)")
    prd_evaluation_report_url: str = Field(default="", description="PRD评估报告PDF下载链接")


# ==================== 测试用例生成独立子图 ====================
class TestCaseGenerationGraphInput(BaseModel):
    """测试用例生成独立子图输入参数
    
    支持上传word、markdown等格式的PRD文件
    """
    prd_file: File = Field(..., description="上传的PRD文件(支持word、markdown等格式)")


class TestCaseGenerationGraphOutput(BaseModel):
    """测试用例生成独立子图输出参数
    
    输出测试用例Excel下载链接
    """
    test_cases: List[Dict[str, Any]] = Field(default=[], description="生成的测试用例列表")
    test_case_excel_url: str = Field(default="", description="测试用例Excel下载链接")


# ==================== 测试用例质量评估独立子图 ====================
class TestCaseQualityGraphInput(BaseModel):
    """测试用例质量评估独立子图输入参数
    
    支持上传excel、xmind等格式的测试用例文件
    """
    test_case_file: File = Field(..., description="上传的测试用例文件(支持excel、xmind等格式)")


class TestCaseQualityGraphOutput(BaseModel):
    """测试用例质量评估独立子图输出参数
    
    输出测试用例质量评估报告PDF下载链接
    """
    test_case_evaluation_score: float = Field(default=0.0, description="测试用例评估分数(0-100)")
    test_case_evaluation_report: str = Field(default="", description="测试用例评估报告(Markdown格式)")
    test_case_evaluation_report_url: str = Field(default="", description="测试用例评估报告PDF下载链接")
    test_case_modification_suggestions: str = Field(default="", description="测试用例修改意见")


# ==================== 测试用例分数判断节点 ====================
class CheckTestCaseScoreInput(BaseModel):
    """测试用例分数判断节点输入"""
    test_case_evaluation_score: float = Field(..., description="测试用例评估分数")
    refinement_count: int = Field(default=0, description="已完善轮次")


class CheckTestCaseScoreOutput(BaseModel):
    """测试用例分数判断节点输出"""
    need_refinement: bool = Field(..., description="是否需要完善(<90分且未完善过)")
    branch_result: str = Field(..., description="分支结果: '输出测试用例' 或 '需要完善'")


# ==================== 测试用例完善节点 ====================
class TestCaseRefinementInput(BaseModel):
    """测试用例完善节点输入"""
    test_cases: List[Dict[str, Any]] = Field(..., description="原始测试用例列表")
    test_case_evaluation_score: float = Field(..., description="原始评估分数")
    test_case_evaluation_report: str = Field(..., description="原始评估报告(Markdown格式)")
    test_case_modification_suggestions: str = Field(default="", description="修改意见")
    prd_content: str = Field(default="", description="PRD文档内容(用于参考)")


class TestCaseRefinementOutput(BaseModel):
    """测试用例完善节点输出"""
    refined_test_cases: List[Dict[str, Any]] = Field(..., description="完善后的测试用例列表")
    refined_test_case_excel_url: str = Field(default="", description="完善后的测试用例Excel文件URL")
    refinement_count: int = Field(default=1, description="完善轮次(固定为1)")


# ==================== 测试用例完善后评估节点 ====================
class TestCaseQualityRefinementInput(BaseModel):
    """测试用例完善后评估节点输入"""
    refined_test_cases: List[Dict[str, Any]] = Field(..., description="完善后的测试用例列表")
    prd_content: str = Field(default="", description="PRD文档内容(用于对照评估)")


class TestCaseQualityRefinementOutput(BaseModel):
    """测试用例完善后评估节点输出"""
    refined_test_case_evaluation_score: float = Field(..., description="完善后的测试用例评估分数(0-100)")
    refined_test_case_evaluation_report_url: str = Field(default="", description="完善后的测试用例评估报告PDF下载链接")
