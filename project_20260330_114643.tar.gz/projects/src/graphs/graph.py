"""
PRD测试准入与测试用例生成工作流 - 主图编排

提供：
1. main_graph - 完整工作流
2. prd_evaluation_graph - PRD评估独立子图
3. test_case_generation_graph - 测试用例生成独立子图
4. test_case_quality_graph - 测试用例质量评估独立子图
"""
from langgraph.graph import StateGraph, END
from langchain_core.runnables import RunnableConfig
from langgraph.runtime import Runtime

from graphs.state import (
    GlobalState,
    GraphInput,
    GraphOutput,
    CheckPrdScoreInput,
    CheckTestCaseScoreInput
)

# 导入节点函数
from graphs.nodes.prd_content_extraction_node import prd_content_extraction_node
from graphs.nodes.prd_evaluation_node import prd_evaluation_node
from graphs.nodes.check_prd_score_node import check_prd_score_node
from graphs.nodes.test_case_generation_node import test_case_generation_node
from graphs.nodes.test_case_quality_node import test_case_quality_node
from graphs.nodes.check_test_case_score_node import check_test_case_score_node
from graphs.nodes.test_case_refinement_node import test_case_refinement_node
from graphs.nodes.test_case_quality_refinement_node import test_case_quality_refinement_node
from graphs.nodes.result_output_node import result_output_node

# 导入独立子图
from graphs.loop_graph import (
    prd_evaluation_graph,
    test_case_generation_graph,
    test_case_quality_graph,
)


# ==================== 条件分支函数 ====================

def route_by_prd_score(state: CheckPrdScoreInput) -> str:
    """
    title: PRD分数路由
    desc: 根据PRD评估分数决定后续流程，≥80分进入测试用例生成，<80分直接输出结果
    """
    if state.prd_evaluation_score >= 80:
        return "进入测试用例生成"
    else:
        return "PRD未通过准入"


def route_by_test_case_score(state: CheckTestCaseScoreInput) -> str:
    """
    title: 测试用例分数路由
    desc: 根据测试用例质量评估分数决定后续流程，≥90分直接输出结果，<90分且未完善过则进入完善流程
    """
    if state.test_case_evaluation_score >= 90:
        return "输出测试用例"
    elif state.refinement_count == 0:
        # 分数<90分且未完善过，进入完善流程
        return "需要完善"
    else:
        # 已完善过1次，直接输出结果（无论分数如何）
        return "输出测试用例"


# ==================== 主图编排 ====================

def create_workflow() -> StateGraph:
    """创建工作流图"""
    
    # 创建状态图
    builder = StateGraph(
        GlobalState,
        input_schema=GraphInput,
        output_schema=GraphOutput
    )
    
    # ==================== 添加节点 ====================
    
    # 1. PRD内容提取节点
    builder.add_node("prd_content_extraction", prd_content_extraction_node)
    
    # 2. PRD评估节点（包含PDF报告生成）
    builder.add_node("prd_evaluation", prd_evaluation_node)
    
    # 3. PRD分数判断节点
    builder.add_node("check_prd_score", check_prd_score_node)
    
    # 4. 测试用例生成节点（包含Excel生成）
    builder.add_node("test_case_generation", test_case_generation_node)
    
    # 5. 测试用例质量评估节点（包含PDF报告生成）
    builder.add_node("test_case_quality", test_case_quality_node)
    
    # 6. 测试用例分数判断节点
    builder.add_node("check_test_case_score", check_test_case_score_node)
    
    # 7. 测试用例完善节点
    builder.add_node("test_case_refinement", test_case_refinement_node)
    
    # 8. 完善后测试用例质量评估节点
    builder.add_node("test_case_quality_refinement", test_case_quality_refinement_node)
    
    # 9. 最终结果输出节点
    builder.add_node("result_output", result_output_node)
    
    # ==================== 设置入口点 ====================
    builder.set_entry_point("prd_content_extraction")
    
    # ==================== 添加边 ====================
    
    # PRD内容提取 -> PRD评估
    builder.add_edge("prd_content_extraction", "prd_evaluation")
    
    # PRD评估 -> PRD分数判断
    builder.add_edge("prd_evaluation", "check_prd_score")
    
    # PRD分数判断 -> 条件分支
    builder.add_conditional_edges(
        source="check_prd_score",
        path=route_by_prd_score,
        path_map={
            "进入测试用例生成": "test_case_generation",
            "PRD未通过准入": "result_output"
        }
    )
    
    # 测试用例生成 -> 测试用例质量评估
    builder.add_edge("test_case_generation", "test_case_quality")
    
    # 测试用例质量评估 -> 测试用例分数判断
    builder.add_edge("test_case_quality", "check_test_case_score")
    
    # 测试用例分数判断 -> 条件分支
    builder.add_conditional_edges(
        source="check_test_case_score",
        path=route_by_test_case_score,
        path_map={
            "输出测试用例": "result_output",
            "需要完善": "test_case_refinement"
        }
    )
    
    # 测试用例完善 -> 完善后质量评估
    builder.add_edge("test_case_refinement", "test_case_quality_refinement")
    
    # 完善后质量评估 -> 最终结果输出
    builder.add_edge("test_case_quality_refinement", "result_output")
    
    # 最终结果输出 -> 结束
    builder.add_edge("result_output", END)
    
    return builder


# 编译图
builder = create_workflow()
main_graph = builder.compile()
